# UltraFast Browser

**Developer: Saad**

Native Android browser (Kotlin + Jetpack Compose + WebView).

## Build a debug APK
1. Android Studio Koala (2024.1) or newer, JDK 17 (bundled).
2. File > Open > select this folder. Let Gradle sync (needs internet the first time).
3. Build > Build APK(s). Output: app/build/outputs/apk/debug/app-debug.apk
   (or run in terminal: ./gradlew assembleDebug)
4. Copy the APK to your phone and install (allow "Install unknown apps").

## Structure
- MainActivity.kt        activity, theme, runtime-permission + file-chooser plumbing, memory trimming
- BrowserState.kt        tabs, WebView setup/clients, incognito (WebView profiles), permissions, downloads, session
- BrowserScreen.kt       browser UI: address bar, suggestions, start page, toolbar, menu, error screen
- Screens.kt             tabs overview, bookmarks, history, downloads, ad-block stats
- SettingsScreen.kt      settings, clear data
- AdBlocker.kt           domain-based blocker, per-site exceptions, stats, list updater
- Data.kt                bookmarks/history store, search engines, URL-vs-search logic, suggestions
- AppSettings.kt         preferences
- DownloadEngine.kt      parallel (up to 32 connections) download engine + notification service
- assets/ads.txt, trackers.txt   bundled filter lists

## Permissions
INTERNET, ACCESS_NETWORK_STATE (core). CAMERA, RECORD_AUDIO, MODIFY_AUDIO_SETTINGS, ACCESS_*_LOCATION
(only when you allow a site's request). WRITE_EXTERNAL_STORAGE (Android 8/9 downloads only).

## Known limits
Domain-based blocking only (no cosmetic filters); incognito isolation needs a recent WebView
(multi-profile support), otherwise closing incognito clears all cookies; no fullscreen video button.

## v1.1 changes
- Recent searches: tap the address bar to see what you searched before (tap to repeat, X to delete, Clear all). Also on the start page. Not recorded in incognito.
- Address bar shows the search text (not the long results URL) on search-result pages.
- Faster downloads: 16 connections by default (Settings > Download connections: 4/8/16/32), small work-stealing chunks, socket reuse, cookie cache, auto fallback if server ignores Range.
- New UI: gradient start page, floating address bar, rounded download cards with ETA, new colours.
