package com.ultrafast.browser

import android.content.Context
import android.net.Uri
import android.webkit.WebResourceResponse
import org.json.JSONObject
import java.io.ByteArrayInputStream
import java.io.File
import java.io.IOException
import java.net.HttpURLConnection
import java.net.URL
import java.util.concurrent.ConcurrentHashMap
import java.util.concurrent.atomic.AtomicInteger

/**
 * Domain-based request blocker. It blocks sub-resource requests (scripts, images, XHR, iframes)
 * to domains on the ad/tracker lists. It cannot block every ad (first-party ads, in-page ads,
 * video ads and cosmetic filtering are not covered).
 */
class AdBlocker(private val ctx: Context, private val settings: AppSettings) {
    @Volatile private var ads: Set<String> = emptySet()
    @Volatile private var trackers: Set<String> = emptySet()
    private val sp = ctx.getSharedPreferences("blockstats", Context.MODE_PRIVATE)
    val adCount = AtomicInteger(sp.getInt("ads", 0))
    val trackerCount = AtomicInteger(sp.getInt("trackers", 0))
    private val perDomain = ConcurrentHashMap<String, Int>()
    @Volatile var lastUpdated: Long = sp.getLong("updated", 0L)

    val adDomainCount: Int get() = ads.size
    val trackerDomainCount: Int get() = trackers.size

    init {
        try {
            val o = JSONObject(sp.getString("domains", "{}") ?: "{}")
            o.keys().forEach { perDomain[it] = o.getInt(it) }
        } catch (_: Exception) { }
        Thread { reload() }.start()
    }

    fun reload() {
        val a = HashSet<String>()
        val t = HashSet<String>()
        try { parseInto(ctx.assets.open("ads.txt").bufferedReader().readLines().asSequence(), a) } catch (_: Exception) { }
        try { parseInto(ctx.assets.open("trackers.txt").bufferedReader().readLines().asSequence(), t) } catch (_: Exception) { }
        val f = File(ctx.filesDir, "filters_ads.txt")
        if (f.exists()) try { parseInto(f.readLines().asSequence(), a) } catch (_: Exception) { }
        ads = a
        trackers = t
    }

    private fun parseInto(lines: Sequence<String>, out: MutableSet<String>) {
        for (l in lines) {
            val s = l.trim().lowercase()
            if (s.isEmpty() || s.startsWith("#")) continue
            val tokens = s.split(Regex("\\s+"))
            val d = if (tokens.size >= 2 && tokens[0][0].isDigit()) tokens[1] else tokens[0]
            if (d.contains('.') && !d.contains('/') && !d.endsWith(".invalid")) out.add(d)
        }
    }

    private fun match(set: Set<String>, host: String): String? {
        var h = host
        while (h.contains('.')) {
            if (h in set) return h
            h = h.substringAfter('.')
        }
        return null
    }

    fun shouldBlock(uri: Uri, isMainFrame: Boolean, pageUrl: String): Boolean {
        if (isMainFrame) return false           // never block the page the user navigated to
        val adOn = settings.adBlock
        val trOn = settings.trackerBlock
        if (!adOn && !trOn) return false
        val scheme = uri.scheme
        if (scheme != "http" && scheme != "https") return false
        val host = uri.host?.lowercase() ?: return false
        val pageHost = Uri.parse(pageUrl).host?.lowercase()
        if (pageHost != null) {
            if (match(settings.exceptionSet, pageHost) != null) return false     // site exception
            if (host == pageHost || host.endsWith(".$pageHost") || pageHost.endsWith(".$host")) return false // first party
        }
        if (trOn) {
            val m = match(trackers, host)
            if (m != null) { trackerCount.incrementAndGet(); perDomain.merge(m, 1) { a, b -> a + b }; return true }
        }
        if (adOn) {
            val m = match(ads, host)
            if (m != null) { adCount.incrementAndGet(); perDomain.merge(m, 1) { a, b -> a + b }; return true }
        }
        return false
    }

    fun emptyResponse(): WebResourceResponse {
        val r = WebResourceResponse("text/plain", "UTF-8", ByteArrayInputStream(ByteArray(0)))
        r.setStatusCodeAndReasonPhrase(204, "Blocked")
        return r
    }

    fun topDomains(n: Int): List<Pair<String, Int>> =
        perDomain.entries.sortedByDescending { it.value }.take(n).map { it.key to it.value }

    fun resetStats() {
        adCount.set(0); trackerCount.set(0); perDomain.clear(); saveStats()
    }

    fun saveStats() {
        val o = JSONObject()
        topDomains(200).forEach { o.put(it.first, it.second) }
        sp.edit().putInt("ads", adCount.get()).putInt("trackers", trackerCount.get())
            .putString("domains", o.toString()).apply()
    }

    /** Downloads the Peter Lowe ad-server list (hosts format). Call from a background thread. */
    fun updateLists(): Int {
        val conn = URL(LIST_URL).openConnection() as HttpURLConnection
        conn.connectTimeout = 10000
        conn.readTimeout = 20000
        try {
            if (conn.responseCode != 200) throw IOException("HTTP ${conn.responseCode}")
            val text = conn.inputStream.bufferedReader().use { it.readText() }
            val parsed = HashSet<String>()
            parseInto(text.lineSequence(), parsed)
            if (parsed.size < 100) throw IOException("Downloaded list looks invalid")
            File(ctx.filesDir, "filters_ads.txt").writeText(parsed.joinToString("\n"))
            lastUpdated = System.currentTimeMillis()
            sp.edit().putLong("updated", lastUpdated).apply()
            reload()
            return parsed.size
        } finally {
            conn.disconnect()
        }
    }

    companion object {
        const val LIST_URL =
            "https://pgl.yoyo.org/adservers/serverlist.php?hostformat=hosts&showintro=0&mimetype=plaintext"
    }
}
