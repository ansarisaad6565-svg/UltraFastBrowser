package com.ultrafast.browser

import android.text.format.DateUtils
import android.widget.Toast
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

@Composable
private fun Section(text: String) {
    Text(text, Modifier.padding(start = 16.dp, top = 20.dp, bottom = 4.dp), fontWeight = FontWeight.SemiBold,
        color = MaterialTheme.colorScheme.primary, fontSize = 13.sp)
}

@Composable
private fun SwitchRow(title: String, subtitle: String?, checked: Boolean, onChange: (Boolean) -> Unit) {
    Row(
        Modifier.fillMaxWidth().clickable { onChange(!checked) }.padding(horizontal = 16.dp, vertical = 10.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Column(Modifier.weight(1f)) {
            Text(title)
            if (subtitle != null) Text(subtitle, fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.6f))
        }
        Switch(checked = checked, onCheckedChange = onChange)
    }
}

@Composable
private fun ActionRow(title: String, subtitle: String?, onClick: () -> Unit) {
    Column(Modifier.fillMaxWidth().clickable(onClick = onClick).padding(horizontal = 16.dp, vertical = 12.dp)) {
        Text(title)
        if (subtitle != null) Text(subtitle, fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.6f))
    }
}

@Composable
private fun ChoiceRow(title: String, value: String, options: List<Pair<String, String>>, onSelect: (String) -> Unit) {
    var open by remember { mutableStateOf(false) }
    ActionRow(title, options.firstOrNull { it.first == value }?.second ?: value) { open = true }
    if (open) AlertDialog(
        onDismissRequest = { open = false },
        title = { Text(title) },
        text = {
            Column {
                options.forEach { (k, label) ->
                    Row(
                        Modifier.fillMaxWidth().clickable { onSelect(k); open = false }.padding(vertical = 6.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        RadioButton(selected = k == value, onClick = { onSelect(k); open = false })
                        Text(label)
                    }
                }
            }
        },
        confirmButton = { TextButton(onClick = { open = false }) { Text("Close") } }
    )
}

@Composable
fun SettingsScreen(state: BrowserState, close: () -> Unit) {
    val s = state.settings
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    var showClear by remember { mutableStateOf(false) }
    var showHome by remember { mutableStateOf(false) }
    var updating by remember { mutableStateOf(false) }
    val ask = listOf("ask" to "Ask every time", "block" to "Always block")

    ScreenScaffold("Settings", close) { pad ->
        LazyColumn(Modifier.padding(pad).fillMaxSize()) {
            item { Section("Search & home") }
            item { ChoiceRow("Default search engine", s.searchEngine, ENGINES.map { it.id to it.name }) { s.searchEngine = it } }
            item { SwitchRow("Search suggestions", "Sends what you type to your search engine", s.suggestions) { s.suggestions = it } }
            item { ActionRow("Homepage", s.homepage.ifBlank { "Built-in start page" }) { showHome = true } }

            item { Section("Appearance") }
            item {
                ChoiceRow("Theme", s.theme, listOf("system" to "System default", "light" to "Light", "dark" to "Dark")) { s.theme = it }
            }

            item { Section("Blocking & privacy") }
            item { SwitchRow("Ad blocking", "Blocks known ad domains in page requests", s.adBlock) { s.adBlock = it } }
            item { SwitchRow("Tracker blocking", "Blocks known analytics and tracking domains", s.trackerBlock) { s.trackerBlock = it } }
            item {
                ActionRow(
                    if (updating) "Updating filter lists..." else "Update filter lists",
                    "Downloads the Peter Lowe ad-server list. Last updated: " +
                        (if (state.blocker.lastUpdated > 0) DateUtils.getRelativeTimeSpanString(state.blocker.lastUpdated).toString() else "never (bundled list in use)")
                ) {
                    if (!updating) {
                        updating = true
                        scope.launch {
                            val r = withContext(Dispatchers.IO) { runCatching { state.blocker.updateLists() } }
                            updating = false
                            Toast.makeText(
                                ctx,
                                r.fold({ "Updated: $it domains" }, { "Update failed: ${it.message}" }),
                                Toast.LENGTH_LONG
                            ).show()
                        }
                    }
                }
            }
            item { ActionRow("Clear browsing data", "History, cookies and site data, cache") { showClear = true } }

            item { Section("Website permissions") }
            item { SwitchRow("JavaScript", "Turning it off breaks most modern sites", s.javascript) { s.javascript = it; state.applyJavascript() } }
            item { ChoiceRow("Camera", s.permCamera, ask) { s.permCamera = it } }
            item { ChoiceRow("Microphone", s.permMic, ask) { s.permMic = it } }
            item { ChoiceRow("Location", s.permLocation, ask) { s.permLocation = it } }

            item { Section("Sites with blocking turned off") }
            if (s.exceptions.isEmpty()) item {
                Text("None. Use the page menu to turn blocking off for a site that breaks.",
                    Modifier.padding(horizontal = 16.dp), fontSize = 13.sp)
            }
            items(s.exceptions.toList()) { host ->
                Row(Modifier.fillMaxWidth().padding(start = 16.dp), verticalAlignment = Alignment.CenterVertically) {
                    Text(host, Modifier.weight(1f))
                    TextButton(onClick = { s.removeException(host) }) { Text("Remove") }
                }
            }

            item { Section("Downloads") }
            item {
                ChoiceRow(
                    "Download connections", s.dlConnections,
                    listOf("4" to "4 (light)", "8" to "8 (balanced)", "16" to "16 (fast - default)", "32" to "32 (maximum)")
                ) { s.dlConnections = it }
            }
            item {
                ChoiceRow("Save downloads to", s.downloadDir, listOf("Downloads" to "Downloads folder", "Documents" to "Documents folder")) { s.downloadDir = it }
            }

            item { Section("About") }
            item { ActionRow("UltraFast Browser 1.1", "Built on Android System WebView. Does not collect or send browsing data.") { } }
            item { ActionRow("Developer", "Saad") { } }
        }
    }

    if (showHome) {
        var text by remember { mutableStateOf(s.homepage) }
        AlertDialog(
            onDismissRequest = { showHome = false },
            title = { Text("Homepage") },
            text = {
                OutlinedTextField(text, { text = it }, singleLine = true,
                    placeholder = { Text("Leave empty for the start page") })
            },
            confirmButton = { TextButton(onClick = { s.homepage = text.trim(); showHome = false }) { Text("Save") } },
            dismissButton = { TextButton(onClick = { showHome = false }) { Text("Cancel") } }
        )
    }

    if (showClear) {
        var h by remember { mutableStateOf(true) }
        var c by remember { mutableStateOf(true) }
        var k by remember { mutableStateOf(true) }
        AlertDialog(
            onDismissRequest = { showClear = false },
            title = { Text("Clear browsing data") },
            text = {
                Column {
                    Row(verticalAlignment = Alignment.CenterVertically) { Checkbox(h, { h = it }); Text("Browsing & search history") }
                    Row(verticalAlignment = Alignment.CenterVertically) { Checkbox(c, { c = it }); Text("Cookies and site data") }
                    Row(verticalAlignment = Alignment.CenterVertically) { Checkbox(k, { k = it }); Text("Cached files") }
                }
            },
            confirmButton = {
                TextButton(onClick = {
                    if (h) { state.store.clearHistory(); state.store.clearSearches() }
                    if (c) state.clearCookiesAndSiteData()
                    if (k) state.clearCache()
                    showClear = false
                    state.toast("Browsing data cleared")
                }) { Text("Clear") }
            },
            dismissButton = { TextButton(onClick = { showClear = false }) { Text("Cancel") } }
        )
    }
}
