package com.ultrafast.browser

import android.content.ComponentCallbacks2
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Bundle
import android.webkit.WebChromeClient
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.SideEffect
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalView
import androidx.core.content.ContextCompat
import androidx.core.view.WindowCompat

class MainActivity : ComponentActivity() {
    private lateinit var settings: AppSettings
    private lateinit var state: BrowserState

    private var permCb: (() -> Unit)? = null
    private var fileCb: ((Array<Uri>?) -> Unit)? = null

    private val permLauncher = registerForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) {
        val cb = permCb
        permCb = null
        cb?.invoke()
    }
    private val fileLauncher = registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { r ->
        val uris = WebChromeClient.FileChooserParams.parseResult(r.resultCode, r.data)
        val cb = fileCb
        fileCb = null
        cb?.invoke(uris)
    }

    /** Requests Android runtime permissions, then reports whether they were granted. */
    fun requestRuntime(perms: Array<String>, requireAll: Boolean, cb: (Boolean) -> Unit) {
        fun granted(): Boolean {
            val g = perms.map { ContextCompat.checkSelfPermission(this, it) == PackageManager.PERMISSION_GRANTED }
            return if (requireAll) g.all { it } else g.any { it }
        }
        val missing = perms.filter { ContextCompat.checkSelfPermission(this, it) != PackageManager.PERMISSION_GRANTED }
        if (missing.isEmpty()) { cb(true); return }
        permCb = { cb(granted()) }
        permLauncher.launch(missing.toTypedArray())
    }

    fun pickFiles(params: WebChromeClient.FileChooserParams, cb: (Array<Uri>?) -> Unit) {
        fileCb?.invoke(null)
        fileCb = cb
        try {
            fileLauncher.launch(params.createIntent())
        } catch (e: Exception) {
            fileCb = null
            cb(null)
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        settings = AppSettings(applicationContext)
        DownloadEngine.connections = { settings.dlConnections.toIntOrNull() ?: 16 }
        DownloadEngine.init(applicationContext)
        val store = Store(applicationContext)
        val blocker = AdBlocker(applicationContext, settings)
        state = BrowserState(this, settings, store, blocker)
        state.restoreSession(intent?.data?.toString())

        setContent {
            val dark = when (settings.theme) {
                "light" -> false
                "dark" -> true
                else -> isSystemInDarkTheme()
            }
            val view = LocalView.current
            SideEffect {
                val c = WindowCompat.getInsetsController(window, view)
                c.isAppearanceLightStatusBars = !dark
                c.isAppearanceLightNavigationBars = !dark
            }
            val scheme = if (dark) darkColorScheme(
                primary = Color(0xFFA99BFF), background = Color(0xFF0D0D14), surface = Color(0xFF171722),
                surfaceVariant = Color(0xFF22222F), outlineVariant = Color(0xFF34344A)
            ) else lightColorScheme(
                primary = Color(0xFF5B4BFF), background = Color(0xFFF4F5FB), surface = Color(0xFFFFFFFF),
                surfaceVariant = Color(0xFFE8EAF7), outlineVariant = Color(0xFFD9DCEE)
            )
            MaterialTheme(colorScheme = scheme) {
                Surface(Modifier.fillMaxSize(), color = MaterialTheme.colorScheme.background) {
                    BrowserApp(state)
                }
            }
        }
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        intent.data?.toString()?.let { state.openExternal(it) }
    }

    override fun onPause() { super.onPause(); state.onPause() }
    override fun onResume() { super.onResume(); state.onResume() }

    @Suppress("DEPRECATION")
    override fun onTrimMemory(level: Int) {
        super.onTrimMemory(level)
        if (level >= ComponentCallbacks2.TRIM_MEMORY_BACKGROUND ||
            level == ComponentCallbacks2.TRIM_MEMORY_RUNNING_LOW ||
            level == ComponentCallbacks2.TRIM_MEMORY_RUNNING_CRITICAL
        ) state.trimMemory()
    }

    override fun onDestroy() {
        state.shutdown(isFinishing)
        super.onDestroy()
    }
}
