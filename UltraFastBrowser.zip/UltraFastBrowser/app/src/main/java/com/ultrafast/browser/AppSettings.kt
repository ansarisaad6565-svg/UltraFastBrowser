package com.ultrafast.browser

import android.content.Context
import android.content.SharedPreferences
import androidx.compose.runtime.*
import kotlin.reflect.KProperty

class StrPref(private val sp: SharedPreferences, private val key: String, def: String) {
    private var v by mutableStateOf(sp.getString(key, def) ?: def)
    operator fun getValue(thisRef: Any?, p: KProperty<*>): String = v
    operator fun setValue(thisRef: Any?, p: KProperty<*>, value: String) {
        v = value; sp.edit().putString(key, value).apply()
    }
}

class BoolPref(private val sp: SharedPreferences, private val key: String, def: Boolean) {
    private var v by mutableStateOf(sp.getBoolean(key, def))
    operator fun getValue(thisRef: Any?, p: KProperty<*>): Boolean = v
    operator fun setValue(thisRef: Any?, p: KProperty<*>, value: Boolean) {
        v = value; sp.edit().putBoolean(key, value).apply()
    }
}

class AppSettings(ctx: Context) {
    private val sp: SharedPreferences = ctx.getSharedPreferences("settings", Context.MODE_PRIVATE)

    var searchEngine by StrPref(sp, "engine", "google")
    var theme by StrPref(sp, "theme", "system")            // system | light | dark
    var homepage by StrPref(sp, "homepage", "")            // "" = built-in start page
    var downloadDir by StrPref(sp, "dlDir", "Downloads")   // Downloads | Documents
    var permCamera by StrPref(sp, "permCam", "ask")        // ask | block
    var permMic by StrPref(sp, "permMic", "ask")
    var permLocation by StrPref(sp, "permLoc", "ask")
    var adBlock by BoolPref(sp, "adBlock", true)
    var trackerBlock by BoolPref(sp, "trackerBlock", true)
    var javascript by BoolPref(sp, "js", true)
    var suggestions by BoolPref(sp, "suggest", true)
    var loadImages by BoolPref(sp, "images", true)
    var dlConnections by StrPref(sp, "dlConn", "16")       // parallel download connections: 4 | 8 | 16 | 32

    /** Sites where blocking is turned off (exceptions for pages that break). */
    val exceptions = mutableStateListOf<String>()
    @Volatile var exceptionSet: Set<String> = emptySet()

    init {
        exceptions.addAll(sp.getStringSet("exceptions", emptySet()) ?: emptySet())
        exceptionSet = exceptions.toSet()
    }

    fun toggleException(host: String) {
        if (!exceptions.remove(host)) exceptions.add(host)
        persistExceptions()
    }

    fun removeException(host: String) {
        exceptions.remove(host); persistExceptions()
    }

    private fun persistExceptions() {
        exceptionSet = exceptions.toSet()
        sp.edit().putStringSet("exceptions", exceptionSet).apply()
    }
}
