package com.ultrafast.browser

import android.app.DownloadManager
import android.content.ActivityNotFoundException
import android.content.Context
import android.content.Intent

data class DlItem(
    val id: Long, val title: String, val status: Int, val total: Long,
    val soFar: Long, val reason: Int, val mime: String?
)

object Downloads {
    fun query(ctx: Context): List<DlItem> {
        val dm = ctx.getSystemService(DownloadManager::class.java) ?: return emptyList()
        val out = ArrayList<DlItem>()
        try {
            dm.query(DownloadManager.Query())?.use { c ->
                val iId = c.getColumnIndex(DownloadManager.COLUMN_ID)
                val iTitle = c.getColumnIndex(DownloadManager.COLUMN_TITLE)
                val iStatus = c.getColumnIndex(DownloadManager.COLUMN_STATUS)
                val iTotal = c.getColumnIndex(DownloadManager.COLUMN_TOTAL_SIZE_BYTES)
                val iSoFar = c.getColumnIndex(DownloadManager.COLUMN_BYTES_DOWNLOADED_SO_FAR)
                val iReason = c.getColumnIndex(DownloadManager.COLUMN_REASON)
                val iMime = c.getColumnIndex(DownloadManager.COLUMN_MEDIA_TYPE)
                while (c.moveToNext()) {
                    out.add(
                        DlItem(
                            c.getLong(iId), c.getString(iTitle) ?: "Download", c.getInt(iStatus),
                            c.getLong(iTotal), c.getLong(iSoFar), c.getInt(iReason), c.getString(iMime)
                        )
                    )
                }
            }
        } catch (_: Exception) { }
        return out.sortedByDescending { it.id }
    }

    fun failureText(reason: Int): String = when (reason) {
        DownloadManager.ERROR_INSUFFICIENT_SPACE -> "Not enough storage space"
        DownloadManager.ERROR_DEVICE_NOT_FOUND -> "Storage not available"
        DownloadManager.ERROR_FILE_ALREADY_EXISTS -> "File already exists"
        DownloadManager.ERROR_HTTP_DATA_ERROR -> "Network error"
        DownloadManager.ERROR_TOO_MANY_REDIRECTS -> "Too many redirects"
        DownloadManager.ERROR_CANNOT_RESUME -> "Cannot resume download"
        DownloadManager.ERROR_UNHANDLED_HTTP_CODE -> "Server refused the download"
        in 400..599 -> "Server error ($reason)"
        else -> "Download failed"
    }

    fun open(ctx: Context, item: DlItem): Boolean {
        val dm = ctx.getSystemService(DownloadManager::class.java) ?: return false
        val uri = dm.getUriForDownloadedFile(item.id) ?: return false
        val i = Intent(Intent.ACTION_VIEW).setDataAndType(uri, item.mime ?: "*/*")
            .addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_ACTIVITY_NEW_TASK)
        return try { ctx.startActivity(i); true } catch (e: ActivityNotFoundException) { false }
    }

    fun share(ctx: Context, item: DlItem): Boolean {
        val dm = ctx.getSystemService(DownloadManager::class.java) ?: return false
        val uri = dm.getUriForDownloadedFile(item.id) ?: return false
        val send = Intent(Intent.ACTION_SEND).setType(item.mime ?: "*/*")
            .putExtra(Intent.EXTRA_STREAM, uri)
            .addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        return try {
            ctx.startActivity(Intent.createChooser(send, "Share").addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)); true
        } catch (e: Exception) { false }
    }

    fun remove(ctx: Context, id: Long) {
        try { ctx.getSystemService(DownloadManager::class.java)?.remove(id) } catch (_: Exception) { }
    }
}
