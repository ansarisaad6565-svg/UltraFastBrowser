package com.ultrafast.browser

import android.content.Context
import android.net.Uri
import android.os.Handler
import android.os.Looper
import androidx.compose.runtime.mutableStateListOf
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder
import java.util.concurrent.Executors

data class Bookmark(val id: Long, val title: String, val url: String)
data class HistoryEntry(val url: String, val title: String, val time: Long)
data class Engine(val id: String, val name: String, val searchUrl: String)

val ENGINES = listOf(
    Engine("google", "Google", "https://www.google.com/search?q="),
    Engine("ddg", "DuckDuckGo", "https://duckduckgo.com/?q="),
    Engine("bing", "Bing", "https://www.bing.com/search?q="),
    Engine("brave", "Brave Search", "https://search.brave.com/search?q="),
    Engine("ecosia", "Ecosia", "https://www.ecosia.org/search?q=")
)

fun engineById(id: String): Engine = ENGINES.firstOrNull { it.id == id } ?: ENGINES[0]

private val IPV4 = Regex("^\\d{1,3}(\\.\\d{1,3}){3}(:\\d+)?(/.*)?$")

/** Decides whether the input is a URL or a search query. Returns "" for blank input. */
fun resolveInput(raw: String, engineId: String): String {
    val t = raw.trim()
    if (t.isEmpty()) return ""
    val lower = t.lowercase()
    if (lower.startsWith("http://") || lower.startsWith("https://")) return t
    if (!t.contains(' ')) {
        val hostPart = t.substringBefore('/').substringBefore(':')
        if (IPV4.matches(t) || hostPart == "localhost") return "http://$t"
        val tld = hostPart.substringAfterLast('.')
        if (hostPart.contains('.') && !hostPart.startsWith('.') && !hostPart.endsWith('.') &&
            tld.length >= 2 && tld.all { it.isLetter() }
        ) return "https://$t"
    }
    return engineById(engineId).searchUrl + URLEncoder.encode(t, "UTF-8")
}

/** If [url] is a results page of one of our search engines, returns the text that was searched. */
fun searchQueryFromUrl(url: String): String? {
    if (url.isBlank()) return null
    return try {
        val u = Uri.parse(url)
        val host = (u.host ?: return null).lowercase().removePrefix("www.")
        val known = ENGINES.any { e -> (Uri.parse(e.searchUrl).host ?: "").lowercase().removePrefix("www.") == host }
        if (!known) null else u.getQueryParameter("q")?.takeIf { it.isNotBlank() }
    } catch (e: Exception) {
        null
    }
}

object Suggestions {
    /** Fetches search suggestions. Sends the typed text to the chosen engine (can be disabled in Settings). */
    fun fetch(engineId: String, query: String): List<String> {
        val base = if (engineId == "ddg") "https://duckduckgo.com/ac/?type=list&q="
        else "https://suggestqueries.google.com/complete/search?client=firefox&q="
        return try {
            val conn = URL(base + URLEncoder.encode(query, "UTF-8")).openConnection() as HttpURLConnection
            conn.connectTimeout = 3000
            conn.readTimeout = 3000
            try {
                if (conn.responseCode != 200) return emptyList()
                val text = conn.inputStream.bufferedReader().use { it.readText() }
                val arr = JSONArray(text).getJSONArray(1)
                (0 until minOf(arr.length(), 6)).map { arr.getString(it) }
            } finally {
                conn.disconnect()
            }
        } catch (e: Exception) {
            emptyList()
        }
    }
}

class Store(ctx: Context) {
    private val dir: File = ctx.filesDir
    private val io = Executors.newSingleThreadExecutor()
    private val handler = Handler(Looper.getMainLooper())
    private var historyDirty = false

    val bookmarks = mutableStateListOf<Bookmark>()
    val history = mutableStateListOf<HistoryEntry>()
    /** Things the user typed into the search box (most recent first). */
    val searches = mutableStateListOf<String>()

    init {
        val sr = read("searches.json")
        for (i in 0 until sr.length()) searches.add(sr.getString(i))
        val b = read("bookmarks.json")
        for (i in 0 until b.length()) {
            val o = b.getJSONObject(i)
            bookmarks.add(Bookmark(o.getLong("id"), o.getString("title"), o.getString("url")))
        }
        val h = read("history.json")
        for (i in 0 until h.length()) {
            val o = h.getJSONObject(i)
            history.add(HistoryEntry(o.getString("url"), o.getString("title"), o.getLong("time")))
        }
    }

    private fun read(name: String): JSONArray =
        try { JSONArray(File(dir, name).readText()) } catch (e: Exception) { JSONArray() }

    private fun write(name: String, arr: JSONArray) {
        val s = arr.toString()
        io.execute { try { File(dir, name).writeText(s) } catch (_: Exception) { } }
    }

    // ----- bookmarks -----
    fun addBookmark(title: String, url: String) {
        bookmarks.add(0, Bookmark(System.currentTimeMillis(), title.ifBlank { url }, url)); saveBookmarks()
    }

    fun updateBookmark(id: Long, title: String, url: String) {
        val i = bookmarks.indexOfFirst { it.id == id }
        if (i >= 0) { bookmarks[i] = Bookmark(id, title.ifBlank { url }, url); saveBookmarks() }
    }

    fun removeBookmark(id: Long) { bookmarks.removeAll { it.id == id }; saveBookmarks() }

    private fun saveBookmarks() {
        val arr = JSONArray()
        bookmarks.forEach { arr.put(JSONObject().put("id", it.id).put("title", it.title).put("url", it.url)) }
        write("bookmarks.json", arr)
    }

    // ----- recent searches -----
    fun addSearch(q: String) {
        val t = q.trim()
        if (t.isEmpty()) return
        searches.removeAll { it.equals(t, ignoreCase = true) }
        searches.add(0, t)
        while (searches.size > 100) searches.removeAt(searches.lastIndex)
        saveSearches()
    }

    fun removeSearch(q: String) { searches.remove(q); saveSearches() }
    fun clearSearches() { searches.clear(); saveSearches() }

    private fun saveSearches() {
        val arr = JSONArray()
        searches.forEach { arr.put(it) }
        write("searches.json", arr)
    }

    // ----- history -----
    fun addHistory(url: String, title: String) {
        if (history.firstOrNull()?.url == url) return
        history.add(0, HistoryEntry(url, title.ifBlank { url }, System.currentTimeMillis()))
        while (history.size > 2000) history.removeAt(history.lastIndex)
        scheduleHistorySave()
    }

    fun updateHistoryTitle(url: String, title: String) {
        val i = history.take(10).indexOfFirst { it.url == url }
        if (i >= 0 && title.isNotBlank()) { history[i] = history[i].copy(title = title); scheduleHistorySave() }
    }

    fun removeHistory(entry: HistoryEntry) { history.remove(entry); scheduleHistorySave() }
    fun clearHistory() { history.clear(); scheduleHistorySave() }

    private fun scheduleHistorySave() {
        if (historyDirty) return
        historyDirty = true
        handler.postDelayed({ flushHistory() }, 2000)
    }

    fun flushHistory() {
        historyDirty = false
        val arr = JSONArray()
        history.forEach { arr.put(JSONObject().put("url", it.url).put("title", it.title).put("time", it.time)) }
        write("history.json", arr)
    }
}
