package com.ultrafast.browser

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.ActivityNotFoundException
import android.content.ContentValues
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.media.MediaScannerConnection
import android.net.Uri
import android.os.Build
import android.os.Environment
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.provider.MediaStore
import android.webkit.URLUtil
import androidx.compose.runtime.mutableStateListOf
import androidx.core.content.ContextCompat
import androidx.core.content.FileProvider
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.io.FileOutputStream
import java.io.IOException
import java.io.RandomAccessFile
import java.net.HttpURLConnection
import java.net.URL
import java.nio.ByteBuffer
import java.nio.channels.FileChannel
import java.util.concurrent.CancellationException
import java.util.concurrent.Executors
import java.util.concurrent.atomic.AtomicInteger
import java.util.concurrent.atomic.AtomicLong
import java.util.concurrent.atomic.AtomicReference

class DlItem(
    val id: Long,
    @Volatile var name: String,
    val url: String,
    val dirName: String,
    val ua: String,
    val referer: String?,
    @Volatile var mime: String?,
    val cd: String?
) {
    companion object {
        const val QUEUED = 0
        const val RUNNING = 1
        const val DONE = 2
        const val FAILED = 3
        const val CANCELED = 4
    }

    @Volatile var status = QUEUED
    @Volatile var total = -1L
    val done = AtomicLong(0)
    @Volatile var speed = 0L
    @Volatile var error: String? = null
    @Volatile var saving = false
    @Volatile var cancelled = false
    @Volatile var uri: String? = null
    @Volatile var path: String? = null
    var cookies: ((String) -> String?)? = null
    val ckCache = java.util.concurrent.ConcurrentHashMap<String, String>()
}

/**
 * Multi-connection downloader. When the server supports HTTP Range requests, the file is split into
 * small chunks that up to 16-32 connections fetch in parallel (work-stealing, so fast connections take
 * more chunks). If a server turns out not to honour Range, it falls back to a single stream.
 * Files are staged in app storage and then saved to Downloads/Documents.
 */
object DownloadEngine {
    /** Number of parallel connections wanted (Settings > Download connections). */
    var connections: () -> Int = { 16 }
    private class RangeRefused(msg: String) : IOException(msg)

    private lateinit var appCtx: Context
    private var inited = false
    val items = mutableStateListOf<DlItem>()
    private val pool = Executors.newCachedThreadPool()
    private val io = Executors.newSingleThreadExecutor()
    private val main = Handler(Looper.getMainLooper())

    fun init(ctx: Context) {
        if (inited) return
        inited = true
        // Let the HTTP stack keep many idle connections so chunk requests reuse sockets (no new TLS handshake each time)
        System.setProperty("http.maxConnections", "64")
        appCtx = ctx.applicationContext
        try {
            val arr = JSONArray(File(appCtx.filesDir, "downloads.json").readText())
            for (i in 0 until arr.length()) {
                val o = arr.getJSONObject(i)
                val it = DlItem(
                    o.getLong("id"), o.getString("name"), o.getString("url"), o.getString("dir"), "", null,
                    o.optString("mime").ifBlank { null }, null
                )
                it.total = o.optLong("total", -1)
                it.uri = o.optString("uri").ifBlank { null }
                it.path = o.optString("path").ifBlank { null }
                val st = o.optInt("status", DlItem.FAILED)
                if (st == DlItem.DONE) { it.status = DlItem.DONE; it.done.set(it.total.coerceAtLeast(0)) }
                else if (st == DlItem.CANCELED) it.status = DlItem.CANCELED
                else { it.status = DlItem.FAILED; it.error = "Interrupted" }
                items.add(it)
            }
        } catch (_: Exception) { }
    }

    private fun save() {
        val arr = JSONArray()
        items.forEach {
            arr.put(
                JSONObject().put("id", it.id).put("name", it.name).put("url", it.url).put("dir", it.dirName)
                    .put("mime", it.mime ?: "").put("total", it.total).put("uri", it.uri ?: "")
                    .put("path", it.path ?: "").put("status", it.status)
            )
        }
        val s = arr.toString()
        io.execute { try { File(appCtx.filesDir, "downloads.json").writeText(s) } catch (_: Exception) { } }
    }

    // ------------------------------------------------------------ public API
    fun start(
        name: String, url: String, ua: String, cd: String?, mime: String?, referer: String?,
        dirName: String, cookies: (String) -> String?
    ): DlItem {
        val item = DlItem(System.currentTimeMillis(), name.replace('/', '_'), url, dirName,
            ua.ifBlank { "Mozilla/5.0 (Linux; Android 14) AppleWebKit/537.36 Chrome/120 Mobile Safari/537.36" },
            referer, mime, cd)
        item.cookies = cookies
        items.add(0, item)
        save()
        launch(item)
        return item
    }

    fun retry(item: DlItem) {
        if (item.status == DlItem.RUNNING || item.status == DlItem.QUEUED) return
        item.cancelled = false; item.error = null; item.done.set(0); item.status = DlItem.QUEUED
        launch(item)
    }

    fun cancel(item: DlItem) { item.cancelled = true }

    fun remove(item: DlItem, deleteFile: Boolean) {
        item.cancelled = true
        if (deleteFile && item.status == DlItem.DONE) {
            try {
                val p = item.path
                val u = item.uri
                if (p != null) File(p).delete()
                else if (u != null) appCtx.contentResolver.delete(Uri.parse(u), null, null)
            } catch (_: Exception) { }
        }
        items.remove(item)
        save()
    }

    fun open(ctx: Context, item: DlItem): Boolean {
        val u = item.uri ?: return false
        val i = Intent(Intent.ACTION_VIEW).setDataAndType(Uri.parse(u), item.mime ?: "*/*")
            .addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_ACTIVITY_NEW_TASK)
        return try { ctx.startActivity(i); true } catch (e: ActivityNotFoundException) { false } catch (e: Exception) { false }
    }

    fun share(ctx: Context, item: DlItem): Boolean {
        val u = item.uri ?: return false
        val send = Intent(Intent.ACTION_SEND).setType(item.mime ?: "*/*")
            .putExtra(Intent.EXTRA_STREAM, Uri.parse(u)).addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        return try {
            ctx.startActivity(Intent.createChooser(send, "Share").addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)); true
        } catch (e: Exception) { false }
    }

    fun active(): List<DlItem> = items.filter { it.status == DlItem.RUNNING || it.status == DlItem.QUEUED }

    // ------------------------------------------------------------ job
    private fun launch(item: DlItem) {
        try {
            ContextCompat.startForegroundService(appCtx, Intent(appCtx, DownloadService::class.java))
        } catch (_: Exception) { }
        pool.execute { run(item) }
    }

    private class Conn(val c: HttpURLConnection, val url: String)

    private fun open(item: DlItem, startUrl: String, range: String?): Conn {
        var url = startUrl
        for (i in 0 until 6) {
            val c = URL(url).openConnection() as HttpURLConnection
            c.instanceFollowRedirects = false
            c.connectTimeout = 12000
            c.readTimeout = 25000
            c.setRequestProperty("User-Agent", item.ua)
            c.setRequestProperty("Accept-Encoding", "identity")
            item.referer?.let { c.setRequestProperty("Referer", it) }
            var ck: String? = item.ckCache[url]
            if (ck == null) {
                ck = try { item.cookies?.invoke(url) } catch (_: Throwable) { null }
                if (ck != null) item.ckCache[url] = ck
            }
            if (!ck.isNullOrBlank()) c.setRequestProperty("Cookie", ck)
            if (range != null) c.setRequestProperty("Range", range)
            val code = c.responseCode
            if (code == 301 || code == 302 || code == 303 || code == 307 || code == 308) {
                val loc = c.getHeaderField("Location")
                c.disconnect()
                if (loc == null) throw IOException("Bad redirect")
                url = URL(URL(url), loc).toString()
                continue
            }
            return Conn(c, url)
        }
        throw IOException("Too many redirects")
    }

    private fun run(item: DlItem) {
        item.status = DlItem.RUNNING
        val dir = appCtx.getExternalFilesDir("downloads") ?: appCtx.cacheDir
        dir.mkdirs()
        val tmp = File(dir, "dl_${item.id}.part")
        val meter = Thread {
            var last = 0L
            var avg = 0.0
            while (item.status == DlItem.RUNNING) {
                try { Thread.sleep(1000) } catch (_: InterruptedException) { }
                val d = item.done.get()
                val inst = (d - last).coerceAtLeast(0).toDouble()
                avg = if (avg == 0.0) inst else avg * 0.4 + inst * 0.6
                item.speed = avg.toLong()
                last = d
            }
            item.speed = 0
        }
        meter.isDaemon = true
        meter.start()
        try {
            val first = open(item, item.url, "bytes=0-")
            val code = first.c.responseCode
            var total = -1L
            var ranged = false
            if (code == 206) {
                total = first.c.getHeaderField("Content-Range")?.substringAfterLast('/')?.toLongOrNull() ?: -1L
                ranged = total > 0
            } else if (code == 200) {
                total = first.c.contentLengthLong
                // Some servers ignore "bytes=0-" but still advertise ranges: try parallel, fall back if refused
                ranged = total > 0 && first.c.getHeaderField("Accept-Ranges")?.equals("bytes", ignoreCase = true) == true
            } else throw IOException("Server returned HTTP $code")

            val respCd = first.c.getHeaderField("Content-Disposition")
            val ct = first.c.contentType?.substringBefore(';')?.trim()
            if (!ct.isNullOrBlank() && ct != "application/octet-stream") item.mime = ct
            if (respCd != null) item.name = URLUtil.guessFileName(first.url, respCd, item.mime).replace('/', '_')
            item.total = total

            if (ranged && total >= 1L * 1024 * 1024) {
                first.c.disconnect()
                try {
                    downloadParallel(item, first.url, total, tmp)
                } catch (e: RangeRefused) {
                    // Server doesn't really support ranges: restart as one plain stream
                    item.done.set(0)
                    val again = open(item, item.url, null)
                    if (again.c.responseCode != 200) throw IOException("Server returned HTTP ${again.c.responseCode}")
                    downloadSingle(item, again.c, tmp)
                }
            } else {
                downloadSingle(item, first.c, tmp)
            }
            if (item.cancelled) throw CancellationException()
            item.saving = true
            publish(item, tmp)
            item.saving = false
            item.status = DlItem.DONE
            notifyDone(item)
        } catch (e: CancellationException) {
            item.status = DlItem.CANCELED
        } catch (e: Exception) {
            item.status = if (item.cancelled) DlItem.CANCELED else DlItem.FAILED
            item.error = e.message ?: "Network error"
        } finally {
            item.saving = false
            tmp.delete()
            main.post { save() }
        }
    }

    private fun downloadParallel(item: DlItem, url: String, total: Long, tmp: File) {
        val conns = connections().coerceIn(2, 32)
        // small chunks + work stealing: every connection always has something to fetch
        val chunk = (total / (conns * 4L)).coerceIn(512L * 1024, 4L * 1024 * 1024)
        val chunks = ((total + chunk - 1) / chunk).toInt()
        val workers = minOf(conns, chunks)
        val next = AtomicInteger(0)
        val failure = AtomicReference<Throwable?>(null)
        RandomAccessFile(tmp, "rw").use { raf ->
            raf.setLength(total)
            val ch = raf.channel
            val threads = (0 until workers).map {
                Thread {
                    try {
                        while (failure.get() == null && !item.cancelled) {
                            val i = next.getAndIncrement()
                            if (i >= chunks) break
                            val s = i * chunk
                            val e = minOf(total - 1, s + chunk - 1)
                            fetchChunk(item, url, s, e, ch)
                        }
                    } catch (t: Throwable) {
                        failure.compareAndSet(null, t)
                    }
                }.also { it.start() }
            }
            threads.forEach { it.join() }
        }
        failure.get()?.let { if (it is Exception) throw it else throw IOException(it.message) }
        if (item.cancelled) throw CancellationException()
        if (item.done.get() != total) throw IOException("Incomplete download")
    }

    private fun fetchChunk(item: DlItem, url: String, start: Long, end: Long, ch: FileChannel) {
        var pos = start
        var attempts = 0
        val buf = ByteArray(128 * 1024)
        while (pos <= end) {
            if (item.cancelled) return
            try {
                val conn = open(item, url, "bytes=$pos-$end")
                if (conn.c.responseCode != 206) {
                    conn.c.disconnect()
                    throw RangeRefused("Server refused ranged download (${conn.c.responseCode})")
                }
                conn.c.inputStream.use { ins ->
                    while (pos <= end) {
                        val want = minOf(buf.size.toLong(), end - pos + 1).toInt()
                        val r = ins.read(buf, 0, want)
                        if (r < 0) break
                        val bb = ByteBuffer.wrap(buf, 0, r)
                        var p = pos
                        while (bb.hasRemaining()) p += ch.write(bb, p)
                        pos += r
                        item.done.addAndGet(r.toLong())
                        attempts = 0
                        if (item.cancelled) return
                    }
                }
                if (pos <= end) throw IOException("Connection closed early")
            } catch (e: RangeRefused) {
                throw e
            } catch (e: IOException) {
                attempts++
                if (attempts > 5) throw e
                try { Thread.sleep(500L * attempts) } catch (_: InterruptedException) { }
            }
        }
    }

    private fun downloadSingle(item: DlItem, c: HttpURLConnection, tmp: File) {
        val buf = ByteArray(256 * 1024)
        c.inputStream.use { ins ->
            FileOutputStream(tmp).use { out ->
                while (true) {
                    val r = ins.read(buf)
                    if (r < 0) break
                    out.write(buf, 0, r)
                    item.done.addAndGet(r.toLong())
                    if (item.cancelled) throw CancellationException()
                }
            }
        }
        if (item.total <= 0) item.total = item.done.get()
    }

    private fun publish(item: DlItem, tmp: File) {
        val ctx = appCtx
        val mime = item.mime ?: "application/octet-stream"
        if (Build.VERSION.SDK_INT >= 29) {
            val docs = item.dirName == Environment.DIRECTORY_DOCUMENTS
            val collection = if (docs) MediaStore.Files.getContentUri("external") else MediaStore.Downloads.EXTERNAL_CONTENT_URI
            val m = if (docs && !(mime.startsWith("application/") || mime.startsWith("text/"))) "application/octet-stream" else mime
            val v = ContentValues().apply {
                put(MediaStore.MediaColumns.DISPLAY_NAME, item.name)
                put(MediaStore.MediaColumns.MIME_TYPE, m)
                put(MediaStore.MediaColumns.RELATIVE_PATH, item.dirName)
                put(MediaStore.MediaColumns.IS_PENDING, 1)
            }
            val uri = ctx.contentResolver.insert(collection, v) ?: throw IOException("Can't create file in ${item.dirName}")
            try {
                val out = ctx.contentResolver.openOutputStream(uri) ?: throw IOException("Can't write file")
                out.use { o -> tmp.inputStream().use { it.copyTo(o, 1024 * 1024) } }
                val ok = ContentValues().apply { put(MediaStore.MediaColumns.IS_PENDING, 0) }
                ctx.contentResolver.update(uri, ok, null, null)
                item.uri = uri.toString()
            } catch (e: Exception) {
                try { ctx.contentResolver.delete(uri, null, null) } catch (_: Exception) { }
                throw e
            }
        } else {
            val pub = Environment.getExternalStoragePublicDirectory(item.dirName)
            pub.mkdirs()
            val base = item.name.substringBeforeLast('.', item.name)
            val ext = item.name.substringAfterLast('.', "")
            var f = File(pub, item.name)
            var n = 1
            while (f.exists()) {
                f = File(pub, if (ext.isEmpty()) "$base ($n)" else "$base ($n).$ext")
                n++
            }
            tmp.copyTo(f, overwrite = false)
            item.path = f.absolutePath
            item.uri = FileProvider.getUriForFile(ctx, "${ctx.packageName}.files", f).toString()
            MediaScannerConnection.scanFile(ctx, arrayOf(f.absolutePath), null, null)
        }
    }

    private fun notifyDone(item: DlItem) {
        try {
            val nm = appCtx.getSystemService(NotificationManager::class.java)
            DownloadService.ensureChannel(appCtx)
            val n = Notification.Builder(appCtx, DownloadService.CHANNEL)
                .setSmallIcon(android.R.drawable.stat_sys_download_done)
                .setContentTitle("Download complete")
                .setContentText(item.name)
                .setAutoCancel(true)
                .build()
            nm.notify((item.id % 100000).toInt() + 10, n)
        } catch (_: Exception) { }
    }
}

class DownloadService : Service() {
    companion object {
        const val CHANNEL = "downloads"
        private const val NOTIF_ID = 1

        fun ensureChannel(ctx: Context) {
            val nm = ctx.getSystemService(NotificationManager::class.java)
            if (nm.getNotificationChannel(CHANNEL) == null) {
                nm.createNotificationChannel(NotificationChannel(CHANNEL, "Downloads", NotificationManager.IMPORTANCE_LOW))
            }
        }
    }

    private val h = Handler(Looper.getMainLooper())

    private val tick = object : Runnable {
        override fun run() {
            val act = DownloadEngine.active()
            if (act.isEmpty()) {
                stopForeground(STOP_FOREGROUND_REMOVE)
                stopSelf()
                return
            }
            getSystemService(NotificationManager::class.java).notify(NOTIF_ID, build(act))
            h.postDelayed(this, 1000)
        }
    }

    private fun build(act: List<DlItem>): Notification {
        val total = act.sumOf { it.total.coerceAtLeast(0) }
        val known = act.all { it.total > 0 }
        val done = act.sumOf { it.done.get() }
        val pct = if (known && total > 0) (done * 100 / total).toInt() else 0
        val speed = act.sumOf { it.speed }
        val title = if (act.size == 1) act[0].name else "${act.size} downloads"
        val text = "%.1f MB/s".format(speed / 1048576.0)
        val pi = PendingIntent.getActivity(
            this, 0, Intent(this, MainActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP),
            PendingIntent.FLAG_IMMUTABLE
        )
        return Notification.Builder(this, CHANNEL)
            .setSmallIcon(android.R.drawable.stat_sys_download)
            .setContentTitle(title)
            .setContentText(text)
            .setProgress(100, pct, !known)
            .setOngoing(true)
            .setContentIntent(pi)
            .build()
    }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        ensureChannel(this)
        val n = build(DownloadEngine.active())
        if (Build.VERSION.SDK_INT >= 29) startForeground(NOTIF_ID, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_DATA_SYNC)
        else startForeground(NOTIF_ID, n)
        h.removeCallbacks(tick)
        h.postDelayed(tick, 500)
        return START_NOT_STICKY
    }

    override fun onDestroy() {
        h.removeCallbacks(tick)
        super.onDestroy()
    }
}
