package com.ultrafast.browser

import android.Manifest
import android.annotation.SuppressLint
import android.app.DownloadManager
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Bitmap
import android.net.ConnectivityManager
import android.net.NetworkCapabilities
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Environment
import android.os.Handler
import android.os.Looper
import android.view.ViewGroup
import android.webkit.CookieManager
import android.webkit.GeolocationPermissions
import android.webkit.PermissionRequest
import android.webkit.RenderProcessGoneDetail
import android.webkit.SslErrorHandler
import android.webkit.URLUtil
import android.webkit.ValueCallback
import android.webkit.WebChromeClient
import android.webkit.WebResourceError
import android.webkit.WebResourceRequest
import android.webkit.WebResourceResponse
import android.webkit.WebSettings
import android.webkit.WebStorage
import android.webkit.WebView
import android.webkit.WebViewClient
import android.net.http.SslError
import android.widget.Toast
import androidx.compose.runtime.*
import androidx.core.content.ContextCompat
import androidx.webkit.ProfileStore
import androidx.webkit.WebViewCompat
import androidx.webkit.WebViewFeature
import org.json.JSONArray
import org.json.JSONObject

data class PageError(val title: String, val message: String, val offline: Boolean, val canProceed: Boolean = false)

class PermissionPrompt(val site: String, val what: String, val onResult: (Boolean) -> Unit)

class BrowserTab(val id: Long, val incognito: Boolean) {
    var title by mutableStateOf("New tab")
    var url by mutableStateOf("")
    var progress by mutableIntStateOf(0)
    var loading by mutableStateOf(false)
    var canForward by mutableStateOf(false)
    var showStart by mutableStateOf(true)
    var error by mutableStateOf<PageError?>(null)
    var version by mutableIntStateOf(0)
    @Volatile var pageUrl: String = ""
    var webView: WebView? = null
    var savedState: Bundle? = null
    var pendingUrl: String? = null
    var timeout: Runnable? = null
    var retries = 0                 // automatic retries used for the current navigation
    var fallbackUrl: String? = null // http:// version to try if a typed "example.com" fails over https
}

class BrowserState(
    private val activity: MainActivity,
    val settings: AppSettings,
    val store: Store,
    val blocker: AdBlocker
) {
    val tabs = mutableStateListOf<BrowserTab>()
    var selectedId by mutableLongStateOf(-1L)
    var permissionPrompt by mutableStateOf<PermissionPrompt?>(null)
    val current: BrowserTab? get() = tabs.firstOrNull { it.id == selectedId }

    private var nextId = 1L
    private val handler = Handler(Looper.getMainLooper())
    private val INCOGNITO = "incognito"

    private val profilesSupported: Boolean by lazy {
        try { WebViewFeature.isFeatureSupported(WebViewFeature.MULTI_PROFILE) } catch (e: Throwable) { false }
    }
    private var warnedNoProfiles = false
    private val sslAllowed = HashSet<String>()   // hosts the user chose to open despite a certificate problem (this session)

    /** Speeds up the first page load: resolves DNS for favourite sites + search engine, and starts WebView early. */
    fun warmUp() {
        val urls = store.bookmarks.take(8).map { it.url } + store.history.take(15).map { it.url } +
            engineById(settings.searchEngine).searchUrl
        val hosts = urls.mapNotNull { try { Uri.parse(it).host } catch (_: Exception) { null } }.distinct().take(16)
        Thread {
            hosts.forEach { try { java.net.InetAddress.getByName(it) } catch (_: Exception) { } }
        }.also { it.isDaemon = true; it.start() }
        handler.post { current?.let { if (it.webView == null) ensureWebView(it) } }
    }

    fun proceedAnyway(tab: BrowserTab) {
        val host: String? = try { Uri.parse(tab.url).host } catch (_: Exception) { null }
        if (host == null) return
        sslAllowed.add(host)
        retry(tab)
    }

    fun applyImages() {
        tabs.forEach { it.webView?.settings?.loadsImagesAutomatically = settings.loadImages }
        current?.let { retry(it) }
    }

    init {
        // A previous incognito session may have been killed with the process: wipe its profile.
        if (profilesSupported) {
            try { ProfileStore.getInstance().deleteProfile(INCOGNITO) } catch (_: Throwable) { }
        }
    }

    fun toast(msg: String) = Toast.makeText(activity, msg, Toast.LENGTH_SHORT).show()

    fun isOnline(): Boolean {
        val cm = activity.getSystemService(ConnectivityManager::class.java) ?: return true
        val n = cm.activeNetwork ?: return false
        val c = cm.getNetworkCapabilities(n) ?: return false
        return c.hasCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET)
    }

    // ---------------------------------------------------------------- tabs

    fun newTab(incognito: Boolean = false, url: String? = null): BrowserTab {
        val t = BrowserTab(nextId++, incognito)
        if (incognito && !profilesSupported && !warnedNoProfiles) {
            warnedNoProfiles = true
            toast("This WebView can't isolate incognito. Closing incognito tabs will clear all cookies.")
        }
        tabs.add(t)
        if (url != null) {
            t.showStart = false
            t.url = url
            t.pageUrl = url
            t.pendingUrl = url
        }
        selectTab(t.id)
        return t
    }

    fun selectTab(id: Long) {
        selectedId = id
        tabs.forEach { if (it.id == id) it.webView?.onResume() else it.webView?.onPause() }
    }

    fun closeTab(id: Long) {
        val idx = tabs.indexOfFirst { it.id == id }
        if (idx < 0) return
        val t = tabs[idx]
        disarm(t)
        destroy(t)
        tabs.removeAt(idx)
        if (t.incognito && tabs.none { it.incognito }) endIncognitoSession()
        if (tabs.isEmpty()) { newTab(); return }
        if (selectedId == id) selectTab(tabs[minOf(idx, tabs.lastIndex)].id)
    }

    private fun destroy(t: BrowserTab) {
        t.webView?.let { w ->
            (w.parent as? ViewGroup)?.removeView(w)
            w.stopLoading()
            w.destroy()
        }
        t.webView = null
        t.version++
    }

    /** Called under memory pressure: background tabs keep their state but release their WebView. */
    fun trimMemory() {
        tabs.forEach { t ->
            val w = t.webView
            if (t.id != selectedId && w != null) {
                val b = Bundle()
                w.saveState(b)
                t.savedState = b
                disarm(t)
                destroy(t)
            }
        }
    }

    fun endIncognitoSession() {
        if (profilesSupported) {
            try { ProfileStore.getInstance().deleteProfile(INCOGNITO); return } catch (_: Throwable) { }
        }
        clearCookiesAndSiteData()
        clearCache()
    }

    fun openExternal(url: String) { newTab(false, url) }

    // ---------------------------------------------------------------- navigation

    fun load(tab: BrowserTab, input: String) {
        val u = resolveInput(input, settings.searchEngine)
        if (u.isEmpty()) return
        // Remember what was searched (never in incognito)
        val isSearch = u.startsWith(engineById(settings.searchEngine).searchUrl)
        if (!tab.incognito && isSearch) store.addSearch(input)
        tab.retries = 0
        // typed "example.com" without a scheme: if https fails completely we try http (like Chrome)
        tab.fallbackUrl = if (!isSearch && u.startsWith("https://") && !input.trim().lowercase().startsWith("https://"))
            "http://" + u.removePrefix("https://") else null
        tab.showStart = false
        tab.error = null
        tab.url = u
        tab.pageUrl = u
        val w = tab.webView
        if (w != null) { applyCacheMode(w, tab); w.loadUrl(u) }
        else { tab.pendingUrl = u; ensureWebView(tab) }
    }


    fun back(tab: BrowserTab) {
        if (tab.showStart) return
        val w = tab.webView
        if (w != null && w.canGoBack()) { w.goBack(); return }
        w?.stopLoading()
        tab.showStart = true
        tab.url = ""
        tab.pageUrl = ""
        tab.title = "New tab"
        tab.loading = false
        tab.error = null
        tab.canForward = false
    }

    fun forward(tab: BrowserTab) { tab.webView?.takeIf { it.canGoForward() }?.goForward() }

    fun goHome(tab: BrowserTab) {
        if (settings.homepage.isBlank()) {
            tab.webView?.stopLoading()
            disarm(tab)
            tab.showStart = true; tab.url = ""; tab.pageUrl = ""; tab.title = "New tab"
            tab.loading = false; tab.error = null; tab.canForward = false
        } else load(tab, settings.homepage)
    }

    fun reloadOrStop(tab: BrowserTab) {
        if (tab.loading) {
            tab.webView?.stopLoading(); disarm(tab); tab.loading = false
        } else retry(tab)
    }

    fun retry(tab: BrowserTab) {
        if (tab.url.isBlank()) return
        tab.retries = 0
        tab.error = null
        val w = tab.webView
        if (w == null) { load(tab, tab.url); return }
        applyCacheMode(w, tab)
        if (tab.progress == 0 || w.url == null) w.loadUrl(tab.url) else w.reload()
    }

    private fun applyCacheMode(w: WebView, tab: BrowserTab) {
        w.settings.cacheMode = when {
            tab.incognito -> WebSettings.LOAD_NO_CACHE
            !isOnline() -> WebSettings.LOAD_CACHE_ELSE_NETWORK
            else -> WebSettings.LOAD_DEFAULT
        }
    }

    fun applyJavascript() {
        tabs.forEach { it.webView?.settings?.javaScriptEnabled = settings.javascript }
        current?.let { retry(it) }
    }

    // ---------------------------------------------------------------- WebView

    fun attachWebView(tab: BrowserTab): WebView {
        val w = ensureWebView(tab)
        (w.parent as? ViewGroup)?.removeView(w)
        w.onResume()
        return w
    }

    fun ensureWebView(tab: BrowserTab): WebView {
        tab.webView?.let { return it }
        val w = createWebView(tab)
        tab.webView = w
        val st = tab.savedState
        if (st != null) {
            tab.savedState = null
            if (w.restoreState(st) == null && tab.url.isNotBlank()) w.loadUrl(tab.url)
        } else {
            val p = tab.pendingUrl
            if (p != null) { tab.pendingUrl = null; applyCacheMode(w, tab); w.loadUrl(p) }
            else if (!tab.showStart && tab.url.isNotBlank()) w.loadUrl(tab.url)
        }
        return w
    }

    @SuppressLint("SetJavaScriptEnabled")
    private fun createWebView(tab: BrowserTab): WebView {
        val wv = WebView(activity)
        if (tab.incognito && profilesSupported) {
            try {
                ProfileStore.getInstance().getOrCreateProfile(INCOGNITO)
                WebViewCompat.setProfile(wv, INCOGNITO)
            } catch (_: Throwable) { }
        }
        val s = wv.settings
        s.javaScriptEnabled = settings.javascript
        s.domStorageEnabled = true
        s.useWideViewPort = true
        s.loadWithOverviewMode = true
        s.setSupportZoom(true)
        s.builtInZoomControls = true
        s.displayZoomControls = false
        s.allowFileAccess = false
        s.allowContentAccess = false
        s.javaScriptCanOpenWindowsAutomatically = false
        s.setGeolocationEnabled(true)
        s.userAgentString = s.userAgentString.replace("; wv", "")
        s.cacheMode = if (tab.incognito) WebSettings.LOAD_NO_CACHE else WebSettings.LOAD_DEFAULT
        s.mixedContentMode = WebSettings.MIXED_CONTENT_COMPATIBILITY_MODE   // pages with a few http images still open
        s.databaseEnabled = true
        s.loadsImagesAutomatically = settings.loadImages
        // Third-party cookies are needed by many logins, captcha / "verify you are human" checks and embedded content
        try { CookieManager.getInstance().setAcceptThirdPartyCookies(wv, true) } catch (_: Throwable) { }

        wv.webViewClient = object : WebViewClient() {
            override fun shouldOverrideUrlLoading(view: WebView?, request: WebResourceRequest?): Boolean {
                val u = request?.url ?: return false
                tab.retries = 0
                val scheme = u.scheme?.lowercase()
                if (scheme == "http" || scheme == "https" || scheme == "about") return false
                if (scheme in listOf("tel", "mailto", "sms", "geo", "market")) {
                    try { activity.startActivity(Intent(Intent.ACTION_VIEW, u)) } catch (_: Exception) { }
                }
                return true
            }

            override fun shouldInterceptRequest(view: WebView?, request: WebResourceRequest?): WebResourceResponse? {
                if (request == null) return null
                return if (blocker.shouldBlock(request.url, request.isForMainFrame, tab.pageUrl)) blocker.emptyResponse() else null
            }

            override fun onPageStarted(view: WebView?, url: String?, favicon: Bitmap?) {
                if (view == null || url == null) return
                tab.loading = true
                tab.progress = 0
                tab.error = null
                tab.url = url
                tab.pageUrl = url
                tab.showStart = false
                tab.title = Uri.parse(url).host ?: url
                // text and layout first: images start once the page is mostly there (faster time-to-readable)
                if (settings.loadImages) view.settings.loadsImagesAutomatically = false
                armTimeout(tab, view)
            }

            override fun onPageFinished(view: WebView?, url: String?) {
                disarm(tab)
                tab.loading = false
                tab.progress = 100
                if (settings.loadImages) view?.settings?.loadsImagesAutomatically = true
                tab.canForward = view?.canGoForward() == true
            }

            override fun doUpdateVisitedHistory(view: WebView?, url: String?, isReload: Boolean) {
                if (url == null) return
                tab.canForward = view?.canGoForward() == true
                if (!tab.incognito && !isReload && (url.startsWith("http://") || url.startsWith("https://"))) {
                    store.addHistory(url, view?.title ?: "")
                }
            }

            override fun onReceivedError(view: WebView?, request: WebResourceRequest?, error: WebResourceError?) {
                if (request == null || !request.isForMainFrame) return
                val code = error?.errorCode ?: 0
                val failing = request.url.toString()
                val transient = code == WebViewClient.ERROR_CONNECT || code == WebViewClient.ERROR_TIMEOUT ||
                    code == WebViewClient.ERROR_IO || code == WebViewClient.ERROR_HOST_LOOKUP
                // 1) typed "example.com": https failed -> try plain http once
                val fb = tab.fallbackUrl
                if (fb != null && (code == WebViewClient.ERROR_CONNECT || code == WebViewClient.ERROR_IO ||
                        code == WebViewClient.ERROR_FAILED_SSL_HANDSHAKE)) {
                    tab.fallbackUrl = null
                    tab.url = fb; tab.pageUrl = fb
                    handler.post { view?.loadUrl(fb) }
                    return
                }
                // 2) temporary network hiccup: retry automatically (up to 2 times) before showing an error
                if (tab.retries < 2 && transient && isOnline()) {
                    tab.retries++
                    tab.loading = true
                    handler.postDelayed({
                        if (tab.webView === view && tab.error == null) view?.loadUrl(failing)
                    }, 400L * tab.retries)
                    return
                }
                disarm(tab)
                tab.loading = false
                view?.settings?.loadsImagesAutomatically = true
                tab.error = errorFor(code, error?.description?.toString())
            }

            override fun onReceivedSslError(view: WebView?, handler: SslErrorHandler?, error: SslError?) {
                val failHost = try { Uri.parse(error?.url ?: "").host } catch (_: Throwable) { null }
                val pageHost = try { Uri.parse(tab.pageUrl).host } catch (_: Throwable) { null }
                if (failHost != null && failHost in sslAllowed) { handler?.proceed(); return }
                handler?.cancel()
                // A bad certificate on some third-party resource must not kill the whole page: only the page itself errors out
                if (failHost != null && pageHost != null && failHost != pageHost) return
                disarm(tab)
                tab.loading = false
                tab.error = PageError(
                    "Connection is not secure",
                    "This site's security certificate is not valid, so loading was blocked to protect you. " +
                        "Only continue if you trust this site and are not entering passwords or payment details.",
                    false, canProceed = true
                )
            }

            override fun onRenderProcessGone(view: WebView?, detail: RenderProcessGoneDetail?): Boolean {
                activity.runOnUiThread {
                    disarm(tab)
                    destroy(tab)
                    tab.loading = false
                    tab.error = PageError(
                        "This page crashed",
                        "The page ran out of memory or isn't compatible with this browser. Try again.", false
                    )
                }
                return true
            }
        }

        wv.webChromeClient = object : WebChromeClient() {
            override fun onProgressChanged(view: WebView?, newProgress: Int) {
                tab.progress = newProgress
                if (newProgress >= 70 && settings.loadImages && view != null && !view.settings.loadsImagesAutomatically) {
                    view.settings.loadsImagesAutomatically = true
                }
            }

            override fun onReceivedTitle(view: WebView?, title: String?) {
                if (title.isNullOrBlank()) return
                tab.title = title
                if (!tab.incognito) view?.url?.let { store.updateHistoryTitle(it, title) }
            }

            override fun onPermissionRequest(request: PermissionRequest?) {
                if (request == null) return
                activity.runOnUiThread { handleWebPermission(request) }
            }

            override fun onGeolocationPermissionsShowPrompt(origin: String?, callback: GeolocationPermissions.Callback?) {
                if (origin == null || callback == null) return
                if (settings.permLocation == "block") { callback.invoke(origin, false, false); return }
                ask(Uri.parse(origin).host ?: origin, "your location") { allow ->
                    if (!allow) callback.invoke(origin, false, false)
                    else activity.requestRuntime(
                        arrayOf(Manifest.permission.ACCESS_FINE_LOCATION, Manifest.permission.ACCESS_COARSE_LOCATION), false
                    ) { ok -> callback.invoke(origin, ok, false) }
                }
            }

            override fun onShowFileChooser(
                webView: WebView?, filePathCallback: ValueCallback<Array<Uri>>?,
                fileChooserParams: FileChooserParams?
            ): Boolean {
                if (filePathCallback == null || fileChooserParams == null) return false
                activity.pickFiles(fileChooserParams) { uris -> filePathCallback.onReceiveValue(uris) }
                return true
            }
        }

        wv.setDownloadListener { url, userAgent, contentDisposition, mimetype, _ ->
            startDownload(tab, url, userAgent, contentDisposition, mimetype)
        }
        return wv
    }

    private fun errorFor(code: Int, desc: String?): PageError {
        if (!isOnline()) return PageError(
            "You're offline",
            "No internet connection. Check Wi-Fi or mobile data, then try again. Pages you opened before may still load from cache.",
            true
        )
        return when (code) {
            WebViewClient.ERROR_HOST_LOOKUP -> PageError("Site can't be found", "The address may be misspelled, or the server could not be found.", false)
            WebViewClient.ERROR_TIMEOUT -> PageError("Connection timed out", "The site took too long to respond.", false)
            WebViewClient.ERROR_CONNECT -> PageError("Couldn't connect", "The server refused or dropped the connection.", false)
            WebViewClient.ERROR_FAILED_SSL_HANDSHAKE -> PageError("Secure connection failed", "A secure connection could not be established.", false)
            WebViewClient.ERROR_UNSUPPORTED_SCHEME -> PageError("Unsupported link", "This browser can't open that kind of address.", false)
            WebViewClient.ERROR_TOO_MANY_REQUESTS -> PageError("Too many requests", "Please wait a moment and try again.", false)
            else -> PageError("Page couldn't load", desc ?: "Unknown error", false)
        }
    }

    private fun armTimeout(tab: BrowserTab, wv: WebView) {
        disarm(tab)
        val r = Runnable {
            if (tab.loading && tab.progress < 15) {
                wv.stopLoading()
                tab.loading = false
                tab.error = PageError("Taking too long", "The site didn't respond in time. Check your connection and try again.", !isOnline())
            }
        }
        tab.timeout = r
        handler.postDelayed(r, 45_000)
    }

    private fun disarm(tab: BrowserTab) {
        tab.timeout?.let { handler.removeCallbacks(it) }
        tab.timeout = null
    }

    // ---------------------------------------------------------------- permissions

    private fun ask(site: String, what: String, onResult: (Boolean) -> Unit) {
        permissionPrompt?.onResult?.invoke(false)
        permissionPrompt = PermissionPrompt(site, what, onResult)
    }

    fun answerPrompt(allow: Boolean) {
        val p = permissionPrompt ?: return
        permissionPrompt = null
        p.onResult(allow)
    }

    private fun handleWebPermission(request: PermissionRequest) {
        val res = request.resources
        val cam = PermissionRequest.RESOURCE_VIDEO_CAPTURE in res
        val mic = PermissionRequest.RESOURCE_AUDIO_CAPTURE in res
        val supported = ArrayList<String>()
        if (cam) supported.add(PermissionRequest.RESOURCE_VIDEO_CAPTURE)
        if (mic) supported.add(PermissionRequest.RESOURCE_AUDIO_CAPTURE)
        if (supported.isEmpty() || (cam && settings.permCamera == "block") || (mic && settings.permMic == "block")) {
            request.deny(); return
        }
        val what = when { cam && mic -> "your camera and microphone"; cam -> "your camera"; else -> "your microphone" }
        ask(request.origin?.host ?: "This site", what) { allow ->
            if (!allow) request.deny()
            else {
                val perms = ArrayList<String>()
                if (cam) perms.add(Manifest.permission.CAMERA)
                if (mic) perms.add(Manifest.permission.RECORD_AUDIO)
                activity.requestRuntime(perms.toTypedArray(), true) { ok ->
                    if (ok) request.grant(supported.toTypedArray()) else request.deny()
                }
            }
        }
    }

    // ---------------------------------------------------------------- downloads

    private fun startDownload(tab: BrowserTab, url: String, ua: String?, cd: String?, mime: String?) {
        if (!(url.startsWith("http://") || url.startsWith("https://"))) {
            toast("This kind of download isn't supported"); return
        }
        val needStorage = Build.VERSION.SDK_INT < 29 &&
            ContextCompat.checkSelfPermission(activity, Manifest.permission.WRITE_EXTERNAL_STORAGE) != PackageManager.PERMISSION_GRANTED
        val needNotif = Build.VERSION.SDK_INT >= 33 &&
            ContextCompat.checkSelfPermission(activity, Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
        val perms = ArrayList<String>()
        if (needStorage) perms.add(Manifest.permission.WRITE_EXTERNAL_STORAGE)
        if (needNotif) perms.add(Manifest.permission.POST_NOTIFICATIONS)
        if (perms.isEmpty()) { enqueue(tab, url, ua, cd, mime); return }
        activity.requestRuntime(perms.toTypedArray(), false) { _ ->
            val storageOk = !needStorage ||
                ContextCompat.checkSelfPermission(activity, Manifest.permission.WRITE_EXTERNAL_STORAGE) == PackageManager.PERMISSION_GRANTED
            if (storageOk) enqueue(tab, url, ua, cd, mime) else toast("Storage permission is needed to save files")
        }
    }

    private fun enqueue(tab: BrowserTab, url: String, ua: String?, cd: String?, mime: String?) {
        try {
            val name = URLUtil.guessFileName(url, cd, mime)
            val dir = if (settings.downloadDir == "Documents") Environment.DIRECTORY_DOCUMENTS else Environment.DIRECTORY_DOWNLOADS
            val incog = tab.incognito && profilesSupported
            DownloadEngine.start(name, url, ua ?: "", cd, mime, tab.pageUrl.ifBlank { null }, dir) { u ->
                try {
                    if (incog) ProfileStore.getInstance().getProfile(INCOGNITO)?.cookieManager?.getCookie(u)
                    else CookieManager.getInstance().getCookie(u)
                } catch (_: Throwable) { null }
            }
            toast("Downloading $name")
        } catch (e: Exception) {
            toast("Couldn't start download")
        }
    }

    // ---------------------------------------------------------------- privacy

    fun clearCookiesAndSiteData() {
        CookieManager.getInstance().removeAllCookies(null)
        CookieManager.getInstance().flush()
        WebStorage.getInstance().deleteAllData()
    }

    fun clearCache() {
        val existing = tabs.firstNotNullOfOrNull { it.webView }
        if (existing != null) existing.clearCache(true)
        else WebView(activity).also { it.clearCache(true); it.destroy() }
    }

    // ---------------------------------------------------------------- session

    fun saveSession() {
        val arr = JSONArray()
        var sel = 0
        tabs.filter { !it.incognito }.forEachIndexed { i, t ->
            arr.put(JSONObject().put("u", if (t.showStart) "" else t.url).put("t", t.title))
            if (t.id == selectedId) sel = i
        }
        activity.getSharedPreferences("session", 0).edit()
            .putString("tabs", arr.toString()).putInt("sel", sel).apply()
    }

    fun restoreSession(externalUrl: String?) {
        val sp = activity.getSharedPreferences("session", 0)
        try {
            val arr = JSONArray(sp.getString("tabs", "[]") ?: "[]")
            for (i in 0 until arr.length()) {
                val o = arr.getJSONObject(i)
                val t = BrowserTab(nextId++, false)
                val u = o.optString("u")
                t.title = o.optString("t", "New tab")
                if (u.isNotBlank()) { t.url = u; t.pageUrl = u; t.pendingUrl = u; t.showStart = false }
                tabs.add(t)
            }
            if (tabs.isNotEmpty()) selectTab(tabs[sp.getInt("sel", 0).coerceIn(0, tabs.lastIndex)].id)
        } catch (_: Exception) { }
        if (externalUrl != null) newTab(false, externalUrl)
        if (tabs.isEmpty()) newTab()
    }

    fun onPause() {
        saveSession()
        blocker.saveStats()
        store.flushHistory()
        tabs.forEach { it.webView?.onPause() }
        CookieManager.getInstance().flush()
    }

    fun onResume() { current?.webView?.onResume() }

    fun shutdown(finishing: Boolean) {
        val hadIncognito = tabs.any { it.incognito }
        if (finishing) {
            tabs.forEach { disarm(it); destroy(it) }
            if (hadIncognito) endIncognitoSession()
        }
    }
}
