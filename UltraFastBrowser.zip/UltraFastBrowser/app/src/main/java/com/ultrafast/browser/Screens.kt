package com.ultrafast.browser

import android.text.format.DateUtils
import android.text.format.Formatter
import androidx.activity.compose.BackHandler
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.delay

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ScreenScaffold(
    title: String, onBack: () -> Unit,
    actions: @Composable RowScope.() -> Unit = {},
    content: @Composable (PaddingValues) -> Unit
) {
    BackHandler(onBack = onBack)
    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text(title) },
                navigationIcon = { IconButton(onClick = onBack) { Icon(Icons.AutoMirrored.Filled.ArrowBack, "Back") } },
                actions = actions
            )
        },
        content = content
    )
}

@Composable
fun EmptyText(msg: String, pad: PaddingValues) {
    Box(Modifier.padding(pad).fillMaxSize(), contentAlignment = Alignment.Center) {
        Text(msg, color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.6f))
    }
}

// ------------------------------------------------------------------ tabs
@Composable
fun TabsScreen(state: BrowserState, close: () -> Unit) {
    ScreenScaffold("Tabs (${state.tabs.size})", close, actions = {
        TextButton(onClick = { state.newTab(true); close() }) { Text("Incognito") }
        IconButton(onClick = { state.newTab(false); close() }) { Icon(Icons.Filled.Add, "New tab") }
    }) { pad ->
        LazyVerticalGrid(
            columns = GridCells.Fixed(2),
            contentPadding = PaddingValues(12.dp),
            horizontalArrangement = Arrangement.spacedBy(12.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp),
            modifier = Modifier.padding(pad).fillMaxSize()
        ) {
            items(state.tabs, key = { it.id }) { t ->
                val selected = t.id == state.selectedId
                val bg = if (t.incognito) Color(0xFF3A3A48) else MaterialTheme.colorScheme.surfaceVariant
                val fg = if (t.incognito) Color.White else MaterialTheme.colorScheme.onSurfaceVariant
                Column(
                    Modifier.clip(RoundedCornerShape(16.dp)).background(bg)
                        .then(
                            if (selected) Modifier.androidxBorder(MaterialTheme.colorScheme.primary) else Modifier
                        )
                        .clickable { state.selectTab(t.id); close() }
                        .padding(12.dp)
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text(
                            if (t.incognito) "Incognito" else if (t.showStart) "New tab" else t.title,
                            color = fg, fontWeight = FontWeight.SemiBold, maxLines = 1,
                            overflow = TextOverflow.Ellipsis, modifier = Modifier.weight(1f)
                        )
                        IconButton(onClick = { state.closeTab(t.id) }, modifier = Modifier.size(28.dp)) {
                            Icon(Icons.Filled.Close, "Close tab", tint = fg, modifier = Modifier.size(18.dp))
                        }
                    }
                    Spacer(Modifier.height(24.dp))
                    Text(
                        if (t.showStart) "Start page" else t.url, color = fg.copy(alpha = 0.7f), fontSize = 12.sp,
                        maxLines = 2, overflow = TextOverflow.Ellipsis
                    )
                }
            }
        }
    }
}

private fun Modifier.androidxBorder(color: Color): Modifier =
    this.then(Modifier.border(BorderStroke(2.dp, color), RoundedCornerShape(16.dp)))

// ------------------------------------------------------------------ bookmarks
@Composable
fun BookmarksScreen(state: BrowserState, close: () -> Unit) {
    var editing by remember { mutableStateOf<Bookmark?>(null) }
    ScreenScaffold("Bookmarks", close) { pad ->
        if (state.store.bookmarks.isEmpty()) EmptyText("No bookmarks yet. Use the menu on a page to add one.", pad)
        else LazyColumn(Modifier.padding(pad).fillMaxSize()) {
            items(state.store.bookmarks.toList()) { b ->
                Row(
                    Modifier.fillMaxWidth().clickable { state.current?.let { state.load(it, b.url) }; close() }
                        .padding(start = 16.dp, top = 8.dp, bottom = 8.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column(Modifier.weight(1f)) {
                        Text(b.title, maxLines = 1, overflow = TextOverflow.Ellipsis, fontWeight = FontWeight.Medium)
                        Text(b.url, maxLines = 1, overflow = TextOverflow.Ellipsis, fontSize = 12.sp,
                            color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.6f))
                    }
                    IconButton(onClick = { editing = b }) { Icon(Icons.Filled.Edit, "Edit") }
                    IconButton(onClick = { state.store.removeBookmark(b.id) }) { Icon(Icons.Filled.Delete, "Delete") }
                }
            }
        }
    }
    editing?.let { b ->
        BookmarkDialog(b, false, { t, u -> state.store.updateBookmark(b.id, t, u); editing = null },
            { state.store.removeBookmark(b.id); editing = null }, { editing = null })
    }
}

// ------------------------------------------------------------------ history
@Composable
fun HistoryScreen(state: BrowserState, close: () -> Unit) {
    var query by remember { mutableStateOf("") }
    var confirm by remember { mutableStateOf(false) }
    ScreenScaffold("History", close, actions = {
        TextButton(onClick = { confirm = true }) { Text("Clear all") }
    }) { pad ->
        Column(Modifier.padding(pad).fillMaxSize()) {
            OutlinedTextField(
                query, { query = it }, singleLine = true, placeholder = { Text("Search history") },
                modifier = Modifier.fillMaxWidth().padding(12.dp)
            )
            val q = query.trim().lowercase()
            val list = state.store.history.filter {
                q.isEmpty() || it.title.lowercase().contains(q) || it.url.lowercase().contains(q)
            }
            if (list.isEmpty()) {
                Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                    Text("Nothing here", color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.6f))
                }
            } else LazyColumn(Modifier.fillMaxSize()) {
                items(list.take(500)) { h ->
                    Row(
                        Modifier.fillMaxWidth().clickable { state.current?.let { state.load(it, h.url) }; close() }
                            .padding(start = 16.dp, top = 6.dp, bottom = 6.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column(Modifier.weight(1f)) {
                            Text(h.title, maxLines = 1, overflow = TextOverflow.Ellipsis, fontWeight = FontWeight.Medium)
                            Text(
                                h.url + "  -  " + DateUtils.getRelativeTimeSpanString(
                                    h.time, System.currentTimeMillis(), DateUtils.MINUTE_IN_MILLIS
                                ),
                                maxLines = 1, overflow = TextOverflow.Ellipsis, fontSize = 12.sp,
                                color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.6f)
                            )
                        }
                        IconButton(onClick = { state.store.removeHistory(h) }) { Icon(Icons.Filled.Close, "Delete entry") }
                    }
                }
            }
        }
    }
    if (confirm) AlertDialog(
        onDismissRequest = { confirm = false },
        title = { Text("Clear all history?") },
        confirmButton = { TextButton(onClick = { state.store.clearHistory(); confirm = false }) { Text("Clear") } },
        dismissButton = { TextButton(onClick = { confirm = false }) { Text("Cancel") } }
    )
}

// ------------------------------------------------------------------ downloads
private fun fmtEta(sec: Long): String = when {
    sec < 60 -> "${sec}s left"
    sec < 3600 -> "${sec / 60}m ${sec % 60}s left"
    else -> "${sec / 3600}h ${(sec % 3600) / 60}m left"
}

@Composable
fun DownloadsScreen(state: BrowserState, close: () -> Unit) {
    val ctx = LocalContext.current
    var tick by remember { mutableIntStateOf(0) }
    LaunchedEffect(Unit) { while (true) { delay(500); tick++ } }
    val unused = tick
    val list = DownloadEngine.items.toList()
    ScreenScaffold("Downloads", close) { pad ->
        if (list.isEmpty()) EmptyText("No downloads yet", pad)
        else LazyColumn(
            Modifier.padding(pad).fillMaxSize(),
            contentPadding = PaddingValues(12.dp), verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            items(list, key = { it.id }) { d ->
                val total = d.total
                val done = d.done.get()
                val size = if (total > 0) Formatter.formatFileSize(ctx, total) else "unknown size"
                val running = d.status == DlItem.RUNNING
                Column(
                    Modifier.fillMaxWidth().clip(RoundedCornerShape(18.dp))
                        .background(MaterialTheme.colorScheme.surfaceVariant).padding(horizontal = 16.dp, vertical = 10.dp)
                ) {
                    Text(d.name, maxLines = 1, overflow = TextOverflow.Ellipsis, fontWeight = FontWeight.Medium)
                    val status = when (d.status) {
                        DlItem.DONE -> "Completed - $size"
                        DlItem.FAILED -> "Failed: " + (d.error ?: "unknown error")
                        DlItem.CANCELED -> "Canceled"
                        DlItem.QUEUED -> "Waiting to start"
                        else -> if (d.saving) "Saving file..." else
                            Formatter.formatFileSize(ctx, done) + " of " + size + " - " +
                                Formatter.formatFileSize(ctx, d.speed) + "/s" +
                                (if (total > 0 && d.speed > 0) " - " + fmtEta(((total - done) / d.speed).coerceAtLeast(0)) else "")
                    }
                    Text(status, fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.65f))
                    if (running && !d.saving) {
                        Spacer(Modifier.height(6.dp))
                        if (total > 0) LinearProgressIndicator(progress = { (done.toFloat() / total).coerceIn(0f, 1f) },
                            modifier = Modifier.fillMaxWidth().height(6.dp).clip(RoundedCornerShape(3.dp)))
                        else LinearProgressIndicator(modifier = Modifier.fillMaxWidth().height(6.dp).clip(RoundedCornerShape(3.dp)))
                    }
                    Row {
                        when (d.status) {
                            DlItem.DONE -> {
                                TextButton(onClick = { if (!DownloadEngine.open(ctx, d)) state.toast("No app can open this file") }) { Text("Open") }
                                TextButton(onClick = { if (!DownloadEngine.share(ctx, d)) state.toast("Can't share this file") }) { Text("Share") }
                                TextButton(onClick = { DownloadEngine.remove(d, true) }) { Text("Delete") }
                            }
                            DlItem.RUNNING, DlItem.QUEUED ->
                                TextButton(onClick = { DownloadEngine.cancel(d) }) { Text("Cancel") }
                            else -> {
                                TextButton(onClick = { DownloadEngine.retry(d) }) { Text("Retry") }
                                TextButton(onClick = { DownloadEngine.remove(d, false) }) { Text("Remove") }
                            }
                        }
                    }
                }
            }
        }
    }
}

// ------------------------------------------------------------------ stats
@Composable
fun StatsScreen(state: BrowserState, close: () -> Unit) {
    var tick by remember { mutableIntStateOf(0) }
    LaunchedEffect(Unit) { while (true) { delay(1000); tick++ } }
    val unused = tick
    val b = state.blocker
    ScreenScaffold("Ad-block stats", close) { pad ->
        LazyColumn(Modifier.padding(pad).fillMaxSize(), contentPadding = PaddingValues(16.dp)) {
            item {
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                    StatCard("Ads blocked", b.adCount.get(), Modifier.weight(1f))
                    StatCard("Trackers blocked", b.trackerCount.get(), Modifier.weight(1f))
                }
                Spacer(Modifier.height(16.dp))
                Text("Filter lists: ${b.adDomainCount} ad domains, ${b.trackerDomainCount} tracker domains" +
                    if (b.lastUpdated > 0) ", updated " + DateUtils.getRelativeTimeSpanString(b.lastUpdated) else " (bundled list)",
                    fontSize = 13.sp)
                Spacer(Modifier.height(8.dp))
                Text("Blocking is domain-based and can't remove every ad (in-page, first-party and video ads may still appear).",
                    fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.6f))
                Spacer(Modifier.height(20.dp))
                Text("Top blocked domains", fontWeight = FontWeight.SemiBold)
                Spacer(Modifier.height(8.dp))
            }
            val top = b.topDomains(15)
            if (top.isEmpty()) item { Text("Nothing blocked yet.") }
            items(top) { (domain, n) ->
                Row(Modifier.fillMaxWidth().padding(vertical = 4.dp)) {
                    Text(domain, Modifier.weight(1f), maxLines = 1, overflow = TextOverflow.Ellipsis)
                    Text("$n")
                }
            }
            item {
                Spacer(Modifier.height(16.dp))
                OutlinedButton(onClick = { b.resetStats() }) { Text("Reset statistics") }
            }
        }
    }
}

@Composable
private fun StatCard(label: String, value: Int, modifier: Modifier) {
    Column(
        modifier.clip(RoundedCornerShape(16.dp)).background(MaterialTheme.colorScheme.surfaceVariant).padding(16.dp)
    ) {
        Text("$value", fontSize = 32.sp, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.primary)
        Text(label, fontSize = 13.sp)
    }
}
