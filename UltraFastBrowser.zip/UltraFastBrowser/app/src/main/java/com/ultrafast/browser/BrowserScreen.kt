package com.ultrafast.browser

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Intent
import android.net.Uri
import androidx.activity.compose.BackHandler
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.automirrored.filled.ArrowForward
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.focus.FocusRequester
import androidx.compose.ui.focus.focusRequester
import androidx.compose.ui.focus.onFocusChanged
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalFocusManager
import androidx.compose.ui.text.TextRange
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.TextFieldValue
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.withContext

enum class Screen { Browser, Tabs, Bookmarks, History, Downloads, Stats, Settings }

@Composable
fun BrowserApp(state: BrowserState) {
    var screen by remember { mutableStateOf(Screen.Browser) }
    val toBrowser = { screen = Screen.Browser }
    when (screen) {
        Screen.Browser -> BrowserScreen(state) { screen = it }
        Screen.Tabs -> TabsScreen(state, toBrowser)
        Screen.Bookmarks -> BookmarksScreen(state, toBrowser)
        Screen.History -> HistoryScreen(state, toBrowser)
        Screen.Downloads -> DownloadsScreen(state, toBrowser)
        Screen.Stats -> StatsScreen(state, toBrowser)
        Screen.Settings -> SettingsScreen(state, toBrowser)
    }
    state.permissionPrompt?.let { p ->
        AlertDialog(
            onDismissRequest = { state.answerPrompt(false) },
            title = { Text("Allow ${p.what}?") },
            text = { Text("${p.site} wants to use ${p.what}.") },
            confirmButton = { TextButton(onClick = { state.answerPrompt(true) }) { Text("Allow") } },
            dismissButton = { TextButton(onClick = { state.answerPrompt(false) }) { Text("Block") } }
        )
    }
}

private fun displayUrl(t: BrowserTab): String =
    if (t.showStart) "" else t.url.removePrefix("https://").removePrefix("http://").removePrefix("www.").trimEnd('/')

@Composable
fun BrowserScreen(state: BrowserState, go: (Screen) -> Unit) {
    val tab = state.current ?: return
    val settings = state.settings
    val ctx = LocalContext.current
    val focus = LocalFocusManager.current
    val requester = remember { FocusRequester() }
    var tfv by remember { mutableStateOf(TextFieldValue("")) }
    var focused by remember { mutableStateOf(false) }
    var menuOpen by remember { mutableStateOf(false) }
    var bookmarkDraft by remember { mutableStateOf<Bookmark?>(null) }

    BackHandler(enabled = focused) { focus.clearFocus() }
    BackHandler(enabled = !focused && !tab.showStart) { state.back(tab) }

    val suggestions by produceState(emptyList<String>(), tfv.text, focused, settings.suggestions) {
        value = emptyList()
        val q = tfv.text.trim()
        if (focused && q.length >= 2 && settings.suggestions && !q.contains("://")) {
            delay(250)
            value = withContext(Dispatchers.IO) { Suggestions.fetch(settings.searchEngine, q) }
        }
    }
    val local: List<Pair<String, String>> =
        if (focused && tfv.text.length >= 2) {
            val q = tfv.text.lowercase()
            (state.store.bookmarks.filter { it.title.lowercase().contains(q) || it.url.lowercase().contains(q) }
                .map { it.url to it.title } +
                state.store.history.take(500).filter { it.title.lowercase().contains(q) || it.url.lowercase().contains(q) }
                    .map { it.url to it.title })
                .distinctBy { it.first }.take(3)
        } else emptyList()

    fun submit(text: String) { focus.clearFocus(); state.load(tab, text) }

    Column(
        Modifier.fillMaxSize().background(MaterialTheme.colorScheme.background)
            .statusBarsPadding().navigationBarsPadding().imePadding()
    ) {
        val barColor = if (tab.incognito) Color(0xFF3A3A48) else MaterialTheme.colorScheme.surfaceVariant
        val barText = if (tab.incognito) Color.White else MaterialTheme.colorScheme.onSurfaceVariant

        // ---------------- address bar
        Row(
            Modifier.fillMaxWidth().padding(horizontal = 10.dp, vertical = 8.dp).height(48.dp)
                .clip(RoundedCornerShape(24.dp)).background(barColor),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Icon(
                when {
                    tab.showStart -> Icons.Filled.Search
                    tab.url.startsWith("https://") -> Icons.Filled.Lock
                    else -> Icons.Filled.Warning
                },
                contentDescription = null, tint = barText,
                modifier = Modifier.padding(start = 14.dp).size(18.dp)
            )
            BasicTextField(
                value = if (focused) tfv else TextFieldValue(displayUrl(tab)),
                onValueChange = { tfv = it },
                singleLine = true,
                textStyle = TextStyle(color = barText, fontSize = 15.sp),
                cursorBrush = SolidColor(barText),
                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Uri, imeAction = ImeAction.Go),
                keyboardActions = KeyboardActions(onGo = { submit(tfv.text) }),
                modifier = Modifier.weight(1f).padding(horizontal = 10.dp).focusRequester(requester)
                    .onFocusChanged { f ->
                        if (f.isFocused && !focused) {
                            val u = tab.url
                            tfv = TextFieldValue(u, TextRange(0, u.length))
                        }
                        focused = f.isFocused
                    },
                decorationBox = { inner ->
                    Box(contentAlignment = Alignment.CenterStart) {
                        val empty = (if (focused) tfv.text else displayUrl(tab)).isEmpty()
                        if (empty) Text(
                            if (tab.incognito) "Incognito - search or type URL" else "Search or type URL",
                            color = barText.copy(alpha = 0.6f), fontSize = 15.sp
                        )
                        inner()
                    }
                }
            )
            if (focused && tfv.text.isNotEmpty()) {
                IconButton(onClick = { tfv = TextFieldValue("") }) {
                    Icon(Icons.Filled.Clear, "Clear", tint = barText)
                }
            } else if (!tab.showStart) {
                IconButton(onClick = { state.reloadOrStop(tab) }) {
                    Icon(if (tab.loading) Icons.Filled.Close else Icons.Filled.Refresh,
                        if (tab.loading) "Stop" else "Refresh", tint = barText)
                }
            }
        }

        if (tab.loading) {
            LinearProgressIndicator(progress = { tab.progress / 100f }, modifier = Modifier.fillMaxWidth().height(3.dp))
        } else Spacer(Modifier.height(3.dp))

        // ---------------- content
        Box(Modifier.weight(1f).fillMaxWidth()) {
            if (tab.showStart) {
                StartPage(state, onSearchClick = { requester.requestFocus() }, open = { state.load(tab, it) })
            } else {
                key(tab.id, tab.version) {
                    AndroidView(modifier = Modifier.fillMaxSize(), factory = { _ -> state.attachWebView(tab) })
                }
            }
            tab.error?.let { e -> ErrorView(e) { state.retry(tab) } }

            if (focused && tfv.text.isNotBlank()) {
                Column(
                    Modifier.fillMaxSize().background(MaterialTheme.colorScheme.background)
                        .verticalScroll(rememberScrollState())
                ) {
                    SuggestionRow(Icons.Filled.Search, "Go / search: ${tfv.text.trim()}") { submit(tfv.text) }
                    local.forEach { (u, t) -> SuggestionRow(Icons.Filled.Star, "$t  -  $u") { submit(u) } }
                    suggestions.forEach { s -> SuggestionRow(Icons.Filled.Search, s) { submit(s) } }
                }
            }
        }

        // ---------------- bottom toolbar
        HorizontalDivider()
        Row(
            Modifier.fillMaxWidth().height(56.dp),
            horizontalArrangement = Arrangement.SpaceEvenly,
            verticalAlignment = Alignment.CenterVertically
        ) {
            IconButton(onClick = { state.back(tab) }, enabled = !tab.showStart) {
                Icon(Icons.AutoMirrored.Filled.ArrowBack, "Back")
            }
            IconButton(onClick = { state.forward(tab) }, enabled = tab.canForward && !tab.showStart) {
                Icon(Icons.AutoMirrored.Filled.ArrowForward, "Forward")
            }
            IconButton(onClick = { state.goHome(tab) }) { Icon(Icons.Filled.Home, "Home") }
            IconButton(onClick = { state.newTab(false); focus.clearFocus() }) { Icon(Icons.Filled.Add, "New tab") }
            IconButton(onClick = { go(Screen.Tabs) }) {
                Box(
                    Modifier.size(24.dp).border(2.dp, LocalContentColor.current, RoundedCornerShape(6.dp)),
                    contentAlignment = Alignment.Center
                ) { Text("${state.tabs.size}", fontSize = 12.sp, fontWeight = FontWeight.Bold) }
            }
            Box {
                IconButton(onClick = { menuOpen = true }) { Icon(Icons.Filled.MoreVert, "Menu") }
                DropdownMenu(expanded = menuOpen, onDismissRequest = { menuOpen = false }) {
                    val close = { menuOpen = false }
                    val host = if (tab.showStart) null else Uri.parse(tab.url).host
                    val bm = state.store.bookmarks.firstOrNull { it.url == tab.url }
                    MItem("New incognito tab", close) { state.newTab(true) }
                    if (!tab.showStart) {
                        MItem(if (bm != null) "Edit bookmark" else "Add bookmark", close) {
                            bookmarkDraft = bm ?: Bookmark(0, tab.title, tab.url)
                        }
                        MItem("Share page", close) {
                            val i = Intent(Intent.ACTION_SEND).setType("text/plain")
                                .putExtra(Intent.EXTRA_TEXT, tab.url)
                            ctx.startActivity(Intent.createChooser(i, "Share"))
                        }
                        MItem("Copy link", close) {
                            ctx.getSystemService(ClipboardManager::class.java)
                                .setPrimaryClip(ClipData.newPlainText("url", tab.url))
                            state.toast("Link copied")
                        }
                        if (host != null) {
                            val off = settings.exceptions.contains(host)
                            MItem(if (off) "Turn blocking ON for this site" else "Turn blocking OFF for this site", close) {
                                settings.toggleException(host)
                                state.retry(tab)
                            }
                        }
                    }
                    HorizontalDivider()
                    MItem("Bookmarks", close) { go(Screen.Bookmarks) }
                    MItem("History", close) { go(Screen.History) }
                    MItem("Downloads", close) { go(Screen.Downloads) }
                    MItem("Ad-block stats", close) { go(Screen.Stats) }
                    MItem("Settings", close) { go(Screen.Settings) }
                }
            }
        }
    }

    bookmarkDraft?.let { d ->
        BookmarkDialog(
            initial = d, isNew = d.id == 0L,
            onSave = { title, url ->
                if (d.id == 0L) state.store.addBookmark(title, url) else state.store.updateBookmark(d.id, title, url)
                bookmarkDraft = null
            },
            onDelete = if (d.id != 0L) ({ state.store.removeBookmark(d.id); bookmarkDraft = null }) else null,
            onDismiss = { bookmarkDraft = null }
        )
    }
}

@Composable
private fun MItem(label: String, close: () -> Unit, action: () -> Unit) {
    DropdownMenuItem(text = { Text(label) }, onClick = { close(); action() })
}

@Composable
private fun SuggestionRow(icon: androidx.compose.ui.graphics.vector.ImageVector, text: String, onClick: () -> Unit) {
    Row(
        Modifier.fillMaxWidth().clickable(onClick = onClick).padding(horizontal = 16.dp, vertical = 14.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Icon(icon, null, Modifier.size(18.dp), tint = MaterialTheme.colorScheme.primary)
        Spacer(Modifier.width(14.dp))
        Text(text, maxLines = 1, overflow = TextOverflow.Ellipsis)
    }
}

@Composable
fun ErrorView(e: PageError, onRetry: () -> Unit) {
    Column(
        Modifier.fillMaxSize().background(MaterialTheme.colorScheme.background).padding(32.dp),
        verticalArrangement = Arrangement.Center, horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Icon(if (e.offline) Icons.Filled.Warning else Icons.Filled.Info, null, Modifier.size(56.dp),
            tint = MaterialTheme.colorScheme.primary)
        Spacer(Modifier.height(16.dp))
        Text(e.title, style = MaterialTheme.typography.titleLarge, textAlign = TextAlign.Center)
        Spacer(Modifier.height(8.dp))
        Text(e.message, textAlign = TextAlign.Center, style = MaterialTheme.typography.bodyMedium)
        Spacer(Modifier.height(20.dp))
        Button(onClick = onRetry) { Text("Try again") }
    }
}

@Composable
fun StartPage(state: BrowserState, onSearchClick: () -> Unit, open: (String) -> Unit) {
    val engine = engineById(state.settings.searchEngine)
    Column(
        Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(24.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Spacer(Modifier.height(40.dp))
        Text("UltraFast", fontSize = 40.sp, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.primary)
        Text("Fast. Private. Minimal.", color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.6f))
        Spacer(Modifier.height(28.dp))
        Row(
            Modifier.fillMaxWidth().height(56.dp).clip(RoundedCornerShape(28.dp))
                .background(MaterialTheme.colorScheme.surfaceVariant).clickable(onClick = onSearchClick)
                .padding(horizontal = 18.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Icon(Icons.Filled.Search, null, tint = MaterialTheme.colorScheme.primary)
            Spacer(Modifier.width(12.dp))
            Text("Search with ${engine.name} or type URL", color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.7f))
        }
        Spacer(Modifier.height(28.dp))
        val items = state.store.bookmarks.take(8)
        if (items.isNotEmpty()) {
            Text("Bookmarks", Modifier.align(Alignment.Start), fontWeight = FontWeight.SemiBold)
            Spacer(Modifier.height(12.dp))
            items.chunked(4).forEach { row ->
                Row(Modifier.fillMaxWidth().padding(bottom = 12.dp)) {
                    row.forEach { b ->
                        Column(
                            Modifier.weight(1f).clickable { open(b.url) }.padding(4.dp),
                            horizontalAlignment = Alignment.CenterHorizontally
                        ) {
                            Box(
                                Modifier.size(48.dp).clip(CircleShape).background(MaterialTheme.colorScheme.surfaceVariant),
                                contentAlignment = Alignment.Center
                            ) { Text(b.title.take(1).uppercase(), fontWeight = FontWeight.Bold, fontSize = 20.sp) }
                            Spacer(Modifier.height(6.dp))
                            Text(b.title, fontSize = 12.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
                        }
                    }
                    repeat(4 - row.size) { Spacer(Modifier.weight(1f)) }
                }
            }
        }
        Spacer(Modifier.height(16.dp))
        val blocked = state.blocker.adCount.get() + state.blocker.trackerCount.get()
        Text("$blocked ads and trackers blocked so far", fontSize = 12.sp,
            color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.55f))
    }
}

@Composable
fun BookmarkDialog(
    initial: Bookmark, isNew: Boolean, onSave: (String, String) -> Unit,
    onDelete: (() -> Unit)?, onDismiss: () -> Unit
) {
    var title by remember { mutableStateOf(initial.title) }
    var url by remember { mutableStateOf(initial.url) }
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(if (isNew) "Add bookmark" else "Edit bookmark") },
        text = {
            Column {
                OutlinedTextField(title, { title = it }, label = { Text("Title") }, singleLine = true)
                Spacer(Modifier.height(8.dp))
                OutlinedTextField(url, { url = it }, label = { Text("URL") }, singleLine = true)
            }
        },
        confirmButton = { TextButton(onClick = { if (url.isNotBlank()) onSave(title, url.trim()) }) { Text("Save") } },
        dismissButton = {
            Row {
                if (onDelete != null) TextButton(onClick = onDelete) { Text("Delete") }
                TextButton(onClick = onDismiss) { Text("Cancel") }
            }
        }
    )
}
