package com.proshot.camera

import android.Manifest
import android.annotation.SuppressLint
import android.content.ContentValues
import android.content.pm.PackageManager
import android.graphics.Color
import android.graphics.drawable.GradientDrawable
import android.hardware.camera2.CameraCharacteristics
import android.hardware.camera2.CaptureRequest
import android.net.Uri
import android.os.Bundle
import android.provider.MediaStore
import android.util.Size
import android.view.GestureDetector
import android.view.Gravity
import android.view.MotionEvent
import android.view.ScaleGestureDetector
import android.view.View
import android.view.WindowManager
import android.widget.FrameLayout
import android.widget.HorizontalScrollView
import android.widget.LinearLayout
import android.widget.SeekBar
import android.widget.TextView
import android.widget.Toast
import androidx.activity.result.IntentSenderRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.camera.camera2.interop.Camera2CameraControl
import androidx.camera.camera2.interop.Camera2CameraInfo
import androidx.camera.camera2.interop.Camera2Interop
import androidx.camera.camera2.interop.CaptureRequestOptions
import androidx.camera.camera2.interop.ExperimentalCamera2Interop
import androidx.camera.core.Camera
import androidx.camera.core.CameraSelector
import androidx.camera.core.FocusMeteringAction
import androidx.camera.core.ImageCapture
import androidx.camera.core.ImageCaptureException
import androidx.camera.core.Preview
import androidx.camera.core.resolutionselector.AspectRatioStrategy
import androidx.camera.core.resolutionselector.ResolutionSelector
import androidx.camera.core.resolutionselector.ResolutionStrategy
import androidx.camera.extensions.ExtensionMode
import androidx.camera.extensions.ExtensionsManager
import androidx.camera.lifecycle.ProcessCameraProvider
import androidx.camera.video.FallbackStrategy
import androidx.camera.video.MediaStoreOutputOptions
import androidx.camera.video.Quality
import androidx.camera.video.QualitySelector
import androidx.camera.video.Recorder
import androidx.camera.video.Recording
import androidx.camera.video.VideoCapture
import androidx.camera.video.VideoRecordEvent
import androidx.camera.view.PreviewView
import androidx.core.content.ContextCompat
import com.google.mlkit.vision.documentscanner.GmsDocumentScannerOptions
import com.google.mlkit.vision.documentscanner.GmsDocumentScanning
import com.google.mlkit.vision.documentscanner.GmsDocumentScanningResult
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.concurrent.CountDownLatch
import java.util.concurrent.Executors
import java.util.concurrent.TimeUnit
import java.util.concurrent.atomic.AtomicInteger
import kotlin.math.abs
import kotlin.math.max

class MainActivity : AppCompatActivity() {

    enum class Mode(val label: String) {
        PHOTO("PHOTO"), PORTRAIT("PORTRAIT"), NIGHT("NIGHT"), HDR("HDR"),
        DOC("DOCUMENT"), VIDEO("VIDEO")
    }

    private lateinit var previewView: PreviewView
    private lateinit var evBar: SeekBar
    private lateinit var focusBar: SeekBar
    private lateinit var flashBtn: TextView
    private lateinit var dslrBtn: TextView
    private lateinit var burstBtn: TextView
    private lateinit var focusBtn: TextView
    private lateinit var zoomRow: LinearLayout
    private lateinit var shutterView: View
    private val modeViews = mutableMapOf<Mode, TextView>()
    private val zoomViews = mutableMapOf<Float, TextView>()

    private var provider: ProcessCameraProvider? = null
    private var extMgr: ExtensionsManager? = null
    private var camera: Camera? = null
    private var imageCapture: ImageCapture? = null
    private var videoCapture: VideoCapture<Recorder>? = null
    private var recording: Recording? = null

    private var lensFacing = CameraSelector.LENS_FACING_BACK
    private var mode = Mode.PHOTO
    private var flashMode = ImageCapture.FLASH_MODE_OFF
    private var dslrBoost = true
    private var burstOn = false          // HQ+ (3-shot merge) - off by default for speed
    private var manualFocus = false
    private var minFocus = 0f
    private var evLower = 0
    private var useSoft = false
    @Volatile private var busy = false
    private val pending = AtomicInteger(0)

    private val executor = Executors.newSingleThreadExecutor()      // capture thread
    private val procExecutor = Executors.newSingleThreadExecutor()  // background processing

    private val permLauncher =
        registerForActivityResult(ActivityResultContracts.RequestPermission()) { ok ->
            if (ok) startCamera() else toast("Camera permission chahiye")
        }

    private val audioLauncher =
        registerForActivityResult(ActivityResultContracts.RequestPermission()) { ok ->
            if (!ok) toast("Mic permission nahi mili, video bina awaaz ke banega")
        }

    private val scanLauncher =
        registerForActivityResult(ActivityResultContracts.StartIntentSenderForResult()) { r ->
            if (r.resultCode == RESULT_OK) {
                val res = GmsDocumentScanningResult.fromActivityResultIntent(r.data)
                val stamp = stamp()
                res?.pages?.forEachIndexed { i, p ->
                    copyToStore(p.imageUri, MediaStore.Images.Media.EXTERNAL_CONTENT_URI,
                        "DOC_${stamp}_${i + 1}.jpg", "image/jpeg", "Pictures/ProShot Docs")
                }
                res?.pdf?.let {
                    copyToStore(it.uri, MediaStore.Downloads.EXTERNAL_CONTENT_URI,
                        "DOC_$stamp.pdf", "application/pdf", "Download/ProShot Docs")
                }
                toast("Document save ho gaya (PDF: Downloads/ProShot Docs)")
            }
        }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        cacheDir.listFiles()?.forEach { it.delete() }
        buildUi()
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.CAMERA)
            == PackageManager.PERMISSION_GRANTED) startCamera()
        else permLauncher.launch(Manifest.permission.CAMERA)
    }

    // ---------------- UI ----------------
    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    private fun label(text: String, size: Float = 14f) = TextView(this).apply {
        this.text = text
        setTextColor(Color.WHITE)
        textSize = size
        setPadding(dp(14), dp(10), dp(14), dp(10))
    }

    private fun topBtn(text: String) = label(text, 12f).apply {
        setPadding(dp(8), dp(10), dp(8), dp(10))
    }

    private fun buildUi() {
        val root = FrameLayout(this).apply {
            setBackgroundColor(Color.BLACK)
            fitsSystemWindows = true
        }
        previewView = PreviewView(this).apply { scaleType = PreviewView.ScaleType.FIT_CENTER }
        root.addView(previewView, FrameLayout.LayoutParams(-1, -1))

        val scale = ScaleGestureDetector(this, object : ScaleGestureDetector.SimpleOnScaleGestureListener() {
            override fun onScale(d: ScaleGestureDetector): Boolean {
                val cam = camera ?: return true
                val z = cam.cameraInfo.zoomState.value?.zoomRatio ?: 1f
                cam.cameraControl.setZoomRatio(z * d.scaleFactor)
                return true
            }
        })
        val tap = GestureDetector(this, object : GestureDetector.SimpleOnGestureListener() {
            override fun onSingleTapUp(e: MotionEvent): Boolean {
                val cam = camera ?: return true
                if (manualFocus) return true
                val pt = previewView.meteringPointFactory.createPoint(e.x, e.y)
                cam.cameraControl.startFocusAndMetering(FocusMeteringAction.Builder(pt).build())
                return true
            }
        })
        previewView.setOnTouchListener { v, ev ->
            scale.onTouchEvent(ev); tap.onTouchEvent(ev)
            if (ev.action == MotionEvent.ACTION_UP) v.performClick()
            true
        }

        // top bar
        val top = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
        }
        flashBtn = topBtn("FLASH: OFF").apply { setOnClickListener { cycleFlash() } }
        dslrBtn = topBtn("LOOK: ON").apply { setOnClickListener { toggleDslr() } }
        burstBtn = topBtn("HQ+: OFF").apply { setOnClickListener { toggleBurst() } }
        focusBtn = topBtn("AF").apply { setOnClickListener { toggleFocusMode() } }
        val flip = topBtn("FLIP").apply { setOnClickListener { flipCamera() } }
        top.addView(flashBtn); top.addView(dslrBtn); top.addView(burstBtn)
        top.addView(focusBtn); top.addView(flip)
        root.addView(top, FrameLayout.LayoutParams(-2, -2, Gravity.TOP or Gravity.CENTER_HORIZONTAL))

        // bottom stack
        val bottom = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER_HORIZONTAL
            setPadding(0, 0, 0, dp(16))
        }
        zoomRow = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER
        }
        bottom.addView(zoomRow, LinearLayout.LayoutParams(-2, -2))

        evBar = SeekBar(this).apply {
            visibility = View.INVISIBLE
            setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                override fun onProgressChanged(s: SeekBar?, p: Int, fromUser: Boolean) {
                    if (fromUser) camera?.cameraControl?.setExposureCompensationIndex(p + evLower)
                }
                override fun onStartTrackingTouch(s: SeekBar?) {}
                override fun onStopTrackingTouch(s: SeekBar?) {}
            })
        }
        bottom.addView(evBar, LinearLayout.LayoutParams(dp(260), -2))

        focusBar = SeekBar(this).apply {
            max = 100
            visibility = View.GONE
            setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                override fun onProgressChanged(s: SeekBar?, p: Int, fromUser: Boolean) {
                    if (fromUser) applyFocus()
                }
                override fun onStartTrackingTouch(s: SeekBar?) {}
                override fun onStopTrackingTouch(s: SeekBar?) {}
            })
        }
        bottom.addView(focusBar, LinearLayout.LayoutParams(dp(260), -2))

        val strip = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        Mode.values().forEach { m ->
            val tv = label(m.label, 13f).apply { setOnClickListener { selectMode(m) } }
            modeViews[m] = tv
            strip.addView(tv)
        }
        val scroll = HorizontalScrollView(this).apply {
            isHorizontalScrollBarEnabled = false
            addView(strip)
        }
        bottom.addView(scroll, LinearLayout.LayoutParams(-2, -2))

        shutterView = View(this).apply {
            background = GradientDrawable().apply {
                shape = GradientDrawable.OVAL
                setColor(Color.WHITE)
                setStroke(dp(5), Color.parseColor("#888888"))
            }
            setOnClickListener { onShutter() }
        }
        bottom.addView(shutterView, LinearLayout.LayoutParams(dp(76), dp(76)).apply { topMargin = dp(10) })
        root.addView(bottom, FrameLayout.LayoutParams(-1, -2, Gravity.BOTTOM))

        setContentView(root)
        highlightMode()
    }

    private fun highlightMode() {
        modeViews.forEach { (m, tv) ->
            tv.setTextColor(if (m == mode) Color.parseColor("#FFD54F") else Color.WHITE)
        }
        (shutterView.background as GradientDrawable)
            .setStroke(dp(5), if (mode == Mode.VIDEO) Color.RED else Color.parseColor("#888888"))
    }

    private fun selectMode(m: Mode) {
        recording?.stop()
        recording = null
        val old = mode
        mode = m
        highlightMode()
        setShutterColor(Color.WHITE)
        if (m == Mode.VIDEO && ContextCompat.checkSelfPermission(this, Manifest.permission.RECORD_AUDIO)
            != PackageManager.PERMISSION_GRANTED) audioLauncher.launch(Manifest.permission.RECORD_AUDIO)
        if (m != Mode.DOC || old == Mode.VIDEO) bindCamera()
    }

    private fun setShutterColor(c: Int) {
        (shutterView.background as GradientDrawable).setColor(c)
    }

    private fun cycleFlash() {
        flashMode = when (flashMode) {
            ImageCapture.FLASH_MODE_OFF -> ImageCapture.FLASH_MODE_AUTO
            ImageCapture.FLASH_MODE_AUTO -> ImageCapture.FLASH_MODE_ON
            else -> ImageCapture.FLASH_MODE_OFF
        }
        imageCapture?.flashMode = flashMode
        flashBtn.text = "FLASH: " + when (flashMode) {
            ImageCapture.FLASH_MODE_AUTO -> "AUTO"
            ImageCapture.FLASH_MODE_ON -> "ON"
            else -> "OFF"
        }
    }

    private fun toggleDslr() {
        dslrBoost = !dslrBoost
        dslrBtn.text = "LOOK: " + if (dslrBoost) "ON" else "OFF"
    }

    private fun toggleBurst() {
        burstOn = !burstOn
        burstBtn.text = "HQ+: " + if (burstOn) "ON" else "OFF"
        if (burstOn) toast("HQ+: 3 shots merge honge - kam noise, zyada detail (flash band hona chahiye)")
    }

    private fun burstActive() =
        mode == Mode.PHOTO && burstOn && flashMode == ImageCapture.FLASH_MODE_OFF

    private fun flipCamera() {
        lensFacing = if (lensFacing == CameraSelector.LENS_FACING_BACK)
            CameraSelector.LENS_FACING_FRONT else CameraSelector.LENS_FACING_BACK
        bindCamera()
    }

    // ---------------- Focus ----------------
    private fun toggleFocusMode() {
        if (!manualFocus && minFocus <= 0f) {
            toast("Is camera me manual focus supported nahi")
            return
        }
        manualFocus = !manualFocus
        updateFocusUi()
        applyFocus()
    }

    private fun updateFocusUi() {
        focusBtn.text = if (manualFocus) "MF" else "AF"
        focusBar.visibility = if (manualFocus) View.VISIBLE else View.GONE
    }

    @androidx.annotation.OptIn(ExperimentalCamera2Interop::class)
    private fun applyFocus() {
        val cam = camera ?: return
        try {
            val b = CaptureRequestOptions.Builder()
            if (manualFocus) {
                b.setCaptureRequestOption(CaptureRequest.CONTROL_AF_MODE,
                    CaptureRequest.CONTROL_AF_MODE_OFF)
                b.setCaptureRequestOption(CaptureRequest.LENS_FOCUS_DISTANCE,
                    minFocus * focusBar.progress / 100f)
            }
            Camera2CameraControl.from(cam.cameraControl).setCaptureRequestOptions(b.build())
        } catch (e: Exception) {
            toast("Focus set nahi hua: ${e.message}")
        }
    }

    // ---------------- Camera ----------------
    private fun startCamera() {
        val f = ProcessCameraProvider.getInstance(this)
        f.addListener({
            provider = f.get()
            val ef = ExtensionsManager.getInstanceAsync(this, provider!!)
            ef.addListener({
                extMgr = ef.get()
                bindCamera()
            }, ContextCompat.getMainExecutor(this))
        }, ContextCompat.getMainExecutor(this))
    }

    @androidx.annotation.OptIn(ExperimentalCamera2Interop::class)
    private fun bindCamera() {
        val p = provider ?: return
        p.unbindAll()
        camera = null
        var selector = CameraSelector.Builder().requireLensFacing(lensFacing).build()

        val preview = Preview.Builder()
            .setResolutionSelector(
                ResolutionSelector.Builder()
                    .setAspectRatioStrategy(AspectRatioStrategy.RATIO_4_3_FALLBACK_AUTO_STRATEGY)
                    .build()
            ).build()
        preview.setSurfaceProvider(previewView.surfaceProvider)

        try {
            if (mode == Mode.VIDEO) {
                imageCapture = null
                useSoft = false
                val recorder = Recorder.Builder()
                    .setQualitySelector(
                        QualitySelector.fromOrderedList(
                            listOf(Quality.UHD, Quality.FHD, Quality.HD),
                            FallbackStrategy.lowerQualityOrHigherThan(Quality.SD)
                        )
                    ).build()
                val vc = VideoCapture.withOutput(recorder)
                videoCapture = vc
                camera = p.bindToLifecycle(this, selector, preview, vc)
            } else {
                videoCapture = null
                val extMode = when (mode) {
                    Mode.PORTRAIT -> ExtensionMode.BOKEH
                    Mode.NIGHT -> ExtensionMode.NIGHT
                    Mode.HDR -> ExtensionMode.HDR
                    else -> ExtensionMode.NONE
                }
                useSoft = false
                var extApplied = false
                if (extMode != ExtensionMode.NONE) {
                    val em = extMgr
                    if (em != null && em.isExtensionAvailable(selector, extMode)) {
                        selector = em.getExtensionEnabledCameraSelector(selector, extMode)
                        extApplied = true
                    } else {
                        useSoft = true
                        toast("Phone ka vendor ${mode.label} app ko nahi deta - app ka apna software ${mode.label} chalega")
                    }
                }

                val multi = mode == Mode.HDR || mode == Mode.NIGHT
                val icb = ImageCapture.Builder()
                    .setCaptureMode(
                        if (multi) ImageCapture.CAPTURE_MODE_MINIMIZE_LATENCY
                        else ImageCapture.CAPTURE_MODE_MAXIMIZE_QUALITY
                    )
                    .setJpegQuality(95)
                    .setFlashMode(flashMode)
                    .setResolutionSelector(
                        ResolutionSelector.Builder()
                            .setAspectRatioStrategy(AspectRatioStrategy.RATIO_4_3_FALLBACK_AUTO_STRATEGY)
                            // 12MP (binned) = best low-light + fast. Full 50MP is slow and noisy.
                            .setResolutionStrategy(
                                ResolutionStrategy(
                                    Size(4000, 3000),
                                    ResolutionStrategy.FALLBACK_RULE_CLOSEST_LOWER_THEN_HIGHER
                                )
                            )
                            .build()
                    )
                if (!extApplied) {
                    val nr = if (multi) CaptureRequest.NOISE_REDUCTION_MODE_FAST
                    else CaptureRequest.NOISE_REDUCTION_MODE_HIGH_QUALITY
                    val ed = if (multi) CaptureRequest.EDGE_MODE_FAST
                    else CaptureRequest.EDGE_MODE_HIGH_QUALITY
                    Camera2Interop.Extender(icb)
                        .setCaptureRequestOption(CaptureRequest.NOISE_REDUCTION_MODE, nr)
                        .setCaptureRequestOption(CaptureRequest.EDGE_MODE, ed)
                }
                imageCapture = icb.build()
                camera = p.bindToLifecycle(this, selector, preview, imageCapture)
            }
            afterBind()
        } catch (e: Exception) {
            toast("Camera start nahi hua: ${e.message}")
        }
    }

    @androidx.annotation.OptIn(ExperimentalCamera2Interop::class)
    private fun afterBind() {
        val cam = camera ?: return
        val range = cam.cameraInfo.exposureState.exposureCompensationRange
        evLower = range.lower
        if (range.upper > range.lower) {
            evBar.max = range.upper - range.lower
            evBar.progress = -range.lower
            evBar.visibility = View.VISIBLE
        } else evBar.visibility = View.INVISIBLE

        minFocus = try {
            Camera2CameraInfo.from(cam.cameraInfo)
                .getCameraCharacteristic(CameraCharacteristics.LENS_INFO_MINIMUM_FOCUS_DISTANCE) ?: 0f
        } catch (e: Exception) { 0f }
        if (manualFocus && minFocus <= 0f) manualFocus = false
        updateFocusUi()
        if (manualFocus) applyFocus()
        updateZoomRow(cam)
    }

    private fun updateZoomRow(cam: Camera) {
        zoomRow.removeAllViews()
        zoomViews.clear()
        val st = cam.cameraInfo.zoomState.value
        val minZ = st?.minZoomRatio ?: 1f
        val maxZ = st?.maxZoomRatio ?: 1f
        val list = ArrayList<Float>()
        if (minZ < 0.95f) list.add(max(0.6f, minZ))
        list.add(1f)
        if (maxZ >= 1.95f) list.add(2f)
        if (maxZ >= 4.95f) list.add(5f)
        for (r in list) {
            val txt = if (r < 1f) String.format(Locale.US, "%.1fx", r) else "${r.toInt()}x"
            val tv = label(txt, 13f).apply {
                setOnClickListener { camera?.cameraControl?.setZoomRatio(r) }
            }
            zoomViews[r] = tv
            zoomRow.addView(tv)
        }
        cam.cameraInfo.zoomState.observe(this) { s ->
            zoomViews.forEach { (r, tv) ->
                tv.setTextColor(if (abs(s.zoomRatio - r) < 0.08f) Color.parseColor("#FFD54F") else Color.WHITE)
            }
        }
    }

    // ---------------- Shutter ----------------
    private fun onShutter() {
        when {
            mode == Mode.DOC -> openScanner()
            mode == Mode.VIDEO -> toggleRecording()
            busy -> toast("Ek second...")
            pending.get() >= 3 -> toast("Pichli photos process ho rahi hain, thoda ruko")
            else -> shoot()
        }
    }

    private fun shoot() {
        if (imageCapture == null) return
        busy = true
        val m = mode
        val soft = useSoft
        val burst = burstActive()
        val look = dslrBoost
        val evs: List<Float?> = when {
            m == Mode.HDR && soft -> listOf(-2f, 0f, 2f)
            m == Mode.NIGHT && soft -> List(6) { 2f }
            m == Mode.PHOTO && burst -> List(3) { null }
            else -> listOf(null)
        }
        if (evs.size > 1) {
            toast(if (m == Mode.NIGHT) "Phone steady rakho..." else "Hilna mat, 1-2 second...")
        }
        executor.execute {
            val frames = ArrayList<File>()
            val base = evBar.progress + evLower
            var changedEv = false
            var lastEv: Float? = null
            try {
                for (ev in evs) {
                    if (ev != null && ev != lastEv) {
                        setEv(evIndexFor(ev), 280)
                        changedEv = true
                        lastEv = ev
                    }
                    captureSync()?.let { frames.add(it) }
                }
            } catch (t: Throwable) {
                toast("Capture error: ${t.message}")
            }
            if (changedEv) setEv(base, 0)
            busy = false   // shutter is free again; processing continues in the background
            if (frames.isEmpty()) {
                toast("Capture nahi hua")
                return@execute
            }
            pending.incrementAndGet()
            procExecutor.execute {
                try {
                    processAndSave(frames, m, soft, burst, look)
                } finally {
                    pending.decrementAndGet()
                }
            }
        }
    }

    private fun processAndSave(frames: List<File>, m: Mode, soft: Boolean, burst: Boolean, look: Boolean) {
        val temps = ArrayList<File>(frames)
        try {
            var out: File = try {
                when {
                    m == Mode.HDR && soft && frames.size >= 2 -> SoftModes.hdr(frames, cacheDir)
                    m == Mode.NIGHT && soft && frames.size >= 2 -> SoftModes.night(frames, cacheDir)
                    m == Mode.PHOTO && burst && frames.size >= 2 -> SoftModes.burst(frames, cacheDir)
                    m == Mode.PORTRAIT && soft -> SoftModes.portrait(frames[0], cacheDir) ?: run {
                        toast("Portrait: koi insaan nahi mila, normal photo save ki")
                        frames[0]
                    }
                    else -> frames[frames.size / 2]
                }
            } catch (t: Throwable) {
                toast("Processing fail (${t.javaClass.simpleName}), normal frame save ki")
                frames[frames.size / 2]
            }
            if (!temps.contains(out)) temps.add(out)
            if (look) {
                out = try { DslrProcessor.enhance(out, cacheDir) } catch (t: Throwable) { out }
                if (!temps.contains(out)) temps.add(out)
            }
            copyToStore(Uri.fromFile(out), MediaStore.Images.Media.EXTERNAL_CONTENT_URI,
                "IMG_${stamp()}.jpg", "image/jpeg", "Pictures/ProShot")
            toast("Photo save ho gayi")
        } catch (t: Throwable) {
            toast("Error: ${t.message}")
        } finally {
            temps.forEach { it.delete() }
        }
    }

    private fun captureSync(): File? {
        val ic = imageCapture ?: return null
        val f = File(cacheDir, "frame_${System.nanoTime()}.jpg")
        val latch = CountDownLatch(1)
        var ok = false
        runOnUiThread {
            ic.takePicture(
                ImageCapture.OutputFileOptions.Builder(f).build(),
                ContextCompat.getMainExecutor(this),
                object : ImageCapture.OnImageSavedCallback {
                    override fun onImageSaved(r: ImageCapture.OutputFileResults) {
                        ok = true
                        latch.countDown()
                    }
                    override fun onError(e: ImageCaptureException) {
                        latch.countDown()
                    }
                })
        }
        latch.await(20, TimeUnit.SECONDS)
        return if (ok) f else null
    }

    private fun setEv(idx: Int, waitMs: Long) {
        try {
            camera?.cameraControl?.setExposureCompensationIndex(idx)?.get(3, TimeUnit.SECONDS)
        } catch (_: Exception) { }
        if (waitMs > 0) {
            try { Thread.sleep(waitMs) } catch (_: InterruptedException) { }
        }
    }

    private fun evIndexFor(ev: Float): Int {
        val st = camera?.cameraInfo?.exposureState ?: return 0
        val step = st.exposureCompensationStep.toFloat()
        val r = st.exposureCompensationRange
        if (step <= 0f) return 0
        return Math.round(ev / step).coerceIn(r.lower, r.upper)
    }

    // ---------------- Video ----------------
    @SuppressLint("MissingPermission")
    private fun toggleRecording() {
        val rec = recording
        if (rec != null) {
            rec.stop()
            recording = null
            setShutterColor(Color.WHITE)
            return
        }
        val vc = videoCapture ?: return
        val cv = ContentValues().apply {
            put(MediaStore.MediaColumns.DISPLAY_NAME, "VID_${stamp()}")
            put(MediaStore.MediaColumns.MIME_TYPE, "video/mp4")
            put(MediaStore.MediaColumns.RELATIVE_PATH, "Movies/ProShot")
        }
        val opts = MediaStoreOutputOptions.Builder(contentResolver, MediaStore.Video.Media.EXTERNAL_CONTENT_URI)
            .setContentValues(cv).build()
        var pr = vc.output.prepareRecording(this, opts)
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.RECORD_AUDIO)
            == PackageManager.PERMISSION_GRANTED) pr = pr.withAudioEnabled()
        setShutterColor(Color.RED)
        recording = pr.start(ContextCompat.getMainExecutor(this)) { ev ->
            if (ev is VideoRecordEvent.Finalize) {
                recording = null
                setShutterColor(Color.WHITE)
                toast(if (ev.hasError()) "Video error" else "Video save ho gaya (Movies/ProShot)")
            }
        }
    }

    // ---------------- Document scanner ----------------
    private fun openScanner() {
        val opts = GmsDocumentScannerOptions.Builder()
            .setGalleryImportAllowed(true)
            .setPageLimit(25)
            .setResultFormats(
                GmsDocumentScannerOptions.RESULT_FORMAT_JPEG,
                GmsDocumentScannerOptions.RESULT_FORMAT_PDF
            )
            .setScannerMode(GmsDocumentScannerOptions.SCANNER_MODE_FULL)
            .build()
        GmsDocumentScanning.getClient(opts)
            .getStartScanIntent(this)
            .addOnSuccessListener { sender ->
                scanLauncher.launch(IntentSenderRequest.Builder(sender).build())
            }
            .addOnFailureListener { toast("Scanner open nahi hua: ${it.message}") }
    }

    // ---------------- Storage helpers ----------------
    private fun stamp() = SimpleDateFormat("yyyyMMdd_HHmmss_SSS", Locale.US).format(Date())

    private fun copyToStore(src: Uri, collection: Uri, name: String, mime: String, relPath: String) {
        try {
            val v = ContentValues().apply {
                put(MediaStore.MediaColumns.DISPLAY_NAME, name)
                put(MediaStore.MediaColumns.MIME_TYPE, mime)
                put(MediaStore.MediaColumns.RELATIVE_PATH, relPath)
                put(MediaStore.MediaColumns.IS_PENDING, 1)
            }
            val dst = contentResolver.insert(collection, v) ?: return
            contentResolver.openInputStream(src)!!.use { i ->
                contentResolver.openOutputStream(dst)!!.use { o -> i.copyTo(o) }
            }
            v.clear()
            v.put(MediaStore.MediaColumns.IS_PENDING, 0)
            contentResolver.update(dst, v, null, null)
        } catch (e: Exception) {
            toast("Save error: ${e.message}")
        }
    }

    private fun toast(msg: String) = runOnUiThread {
        Toast.makeText(this, msg, Toast.LENGTH_SHORT).show()
    }
}
