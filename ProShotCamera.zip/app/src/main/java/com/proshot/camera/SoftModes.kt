package com.proshot.camera

import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Canvas
import android.graphics.Matrix
import android.graphics.Paint
import android.graphics.Rect
import androidx.exifinterface.media.ExifInterface
import com.google.android.gms.tasks.Tasks
import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.segmentation.Segmentation
import com.google.mlkit.vision.segmentation.selfie.SelfieSegmenterOptions
import java.io.File
import java.io.FileOutputStream
import kotlin.math.abs
import kotlin.math.exp
import kotlin.math.floor
import kotlin.math.max
import kotlin.math.min

/**
 * Multi-frame modes (HDR, Night, HQ+ burst) and software Portrait.
 * All heavy loops run on every CPU core. Merged images are cropped by CROP px on every side,
 * so alignment never leaves smeared edges.
 */
object SoftModes {

    private const val MAX_PIXELS = 13_000_000L
    private const val CROP = 40   // >= max alignment shift (4*8 + 3*2 = 38)

    private class Luma(val w: Int, val h: Int, val d: FloatArray)
    private class Frame(val w: Int, val h: Int, val px: IntArray)

    // ---------- helpers ----------
    internal fun decode(f: File): Bitmap {
        val o = BitmapFactory.Options().apply { inJustDecodeBounds = true }
        BitmapFactory.decodeFile(f.absolutePath, o)
        var s = 1
        while ((o.outWidth / s).toLong() * (o.outHeight / s) > MAX_PIXELS) s *= 2
        val o2 = BitmapFactory.Options().apply {
            inSampleSize = s
            inPreferredConfig = Bitmap.Config.ARGB_8888
            inMutable = true
        }
        return BitmapFactory.decodeFile(f.absolutePath, o2)
            ?: throw IllegalStateException("decode failed")
    }

    private fun loadPx(f: File): Frame {
        val b = decode(f)
        val px = IntArray(b.width * b.height)
        b.getPixels(px, 0, b.width, 0, 0, b.width, b.height)
        val fr = Frame(b.width, b.height, px)
        b.recycle()
        return fr
    }

    private fun yv(p: Int): Int =
        (77 * ((p shr 16) and 255) + 150 * ((p shr 8) and 255) + 29 * (p and 255)) shr 8

    private fun lumaPx(px: IntArray, w: Int, h: Int, s: Int): Luma {
        val lw = w / s
        val lh = h / s
        val d = FloatArray(lw * lh)
        val o1 = s / 4
        val o2 = (3 * s) / 4
        for (ly in 0 until lh) {
            val r1 = (ly * s + o1) * w
            val r2 = (ly * s + o2) * w
            for (lx in 0 until lw) {
                val a = lx * s + o1
                val b = lx * s + o2
                d[ly * lw + lx] = (yv(px[r1 + a]) + yv(px[r1 + b]) + yv(px[r2 + a]) + yv(px[r2 + b])) / 4f
            }
        }
        return Luma(lw, lh, d)
    }

    private fun norm(l: Luma): Luma {
        var m = 0.0
        for (v in l.d) m += v
        m /= l.d.size
        var s = 0.0
        for (v in l.d) { val t = v - m; s += t * t }
        val sd = Math.sqrt(s / l.d.size).toFloat().coerceAtLeast(1f)
        val mf = m.toFloat()
        return Luma(l.w, l.h, FloatArray(l.d.size) { (l.d[it] - mf) / sd })
    }

    /** finds (dx,dy) so that ref(x,y) ~ cur(x+dx, y+dy) */
    private fun search(ref: Luma, cur: Luma, cx: Int, cy: Int, range: Int, step: Int): IntArray {
        val w = ref.w
        val h = ref.h
        var best = Float.MAX_VALUE
        var bx = cx
        var by = cy
        for (dy in cy - range..cy + range) {
            for (dx in cx - range..cx + range) {
                val x0 = max(0, -dx)
                val x1 = min(w, w - dx)
                val y0 = max(0, -dy)
                val y1 = min(h, h - dy)
                if (x1 - x0 < w / 2 || y1 - y0 < h / 2) continue
                var sum = 0f
                var cnt = 0
                var y = y0
                while (y < y1) {
                    val ro = y * w
                    val co = (y + dy) * w + dx
                    var x = x0
                    while (x < x1) {
                        val d = ref.d[ro + x] - cur.d[co + x]
                        sum += d * d
                        cnt++
                        x += step
                    }
                    y += step
                }
                if (cnt == 0) continue
                val m = sum / cnt
                if (m < best) { best = m; bx = dx; by = dy }
            }
        }
        return intArrayOf(bx, by)
    }

    private fun alignShift(r8: Luma, r2: Luma, fr: Frame): IntArray {
        val c = search(r8, norm(lumaPx(fr.px, fr.w, fr.h, 8)), 0, 0, 4, 2)
        val f = search(r2, norm(lumaPx(fr.px, fr.w, fr.h, 2)), c[0] * 4, c[1] * 4, 3, 3)
        return intArrayOf(f[0] * 2, f[1] * 2)
    }

    private fun saveJpeg(bmp: Bitmap, cacheDir: File, exifSrc: File, keepOrientation: Boolean): File {
        val dst = File(cacheDir, "soft_${System.nanoTime()}.jpg")
        FileOutputStream(dst).use { bmp.compress(Bitmap.CompressFormat.JPEG, 97, it) }
        bmp.recycle()
        try {
            val a = ExifInterface(exifSrc.absolutePath)
            val b = ExifInterface(dst.absolutePath)
            val tags = mutableListOf(
                ExifInterface.TAG_DATETIME, ExifInterface.TAG_MAKE, ExifInterface.TAG_MODEL,
                ExifInterface.TAG_EXPOSURE_TIME, ExifInterface.TAG_F_NUMBER,
                ExifInterface.TAG_FOCAL_LENGTH
            )
            if (keepOrientation) tags.add(ExifInterface.TAG_ORIENTATION)
            tags.forEach { t -> a.getAttribute(t)?.let { v -> b.setAttribute(t, v) } }
            b.saveAttributes()
        } catch (_: Exception) { }
        return dst
    }

    private fun toBitmap(out: IntArray, ow: Int, oh: Int): Bitmap {
        val bmp = Bitmap.createBitmap(ow, oh, Bitmap.Config.ARGB_8888)
        bmp.setPixels(out, 0, ow, 0, 0, ow, oh)
        return bmp
    }

    // ---------- HQ+ burst: 3 frames, align, robust (ghost-safe) merge ----------
    fun burst(files: List<File>, cacheDir: File): File {
        val n = files.size
        val ref = n / 2
        val fr = files.map { loadPx(it) }
        val w = fr[0].w
        val h = fr[0].h
        val r8 = norm(lumaPx(fr[ref].px, w, h, 8))
        val r2 = norm(lumaPx(fr[ref].px, w, h, 2))
        val dx = IntArray(n)
        val dy = IntArray(n)
        for (k in 0 until n) {
            if (k == ref) continue
            val s = alignShift(r8, r2, fr[k])
            dx[k] = s[0]
            dy[k] = s[1]
        }
        val ow = w - 2 * CROP
        val oh = h - 2 * CROP
        val out = IntArray(ow * oh)
        Par.rows(oh) { y0, y1 ->
            for (y in y0 until y1) {
                for (x in 0 until ow) {
                    val p0 = fr[ref].px[(y + CROP) * w + x + CROP]
                    val yy0 = yv(p0)
                    var sr = ((p0 shr 16) and 255).toFloat()
                    var sg = ((p0 shr 8) and 255).toFloat()
                    var sb = (p0 and 255).toFloat()
                    var sw = 1f
                    for (k in 0 until n) {
                        if (k == ref) continue
                        val sy = (y + CROP + dy[k]).coerceIn(0, h - 1)
                        val sx = (x + CROP + dx[k]).coerceIn(0, w - 1)
                        val p = fr[k].px[sy * w + sx]
                        val d = abs(yv(p) - yy0)
                        val wt = if (d <= 10) 1f else if (d >= 30) 0f else (30 - d) / 20f
                        if (wt > 0f) {
                            sr += wt * ((p shr 16) and 255)
                            sg += wt * ((p shr 8) and 255)
                            sb += wt * (p and 255)
                            sw += wt
                        }
                    }
                    val r = (sr / sw + 0.5f).toInt().coerceIn(0, 255)
                    val g = (sg / sw + 0.5f).toInt().coerceIn(0, 255)
                    val b = (sb / sw + 0.5f).toInt().coerceIn(0, 255)
                    out[y * ow + x] = (0xFF shl 24) or (r shl 16) or (g shl 8) or b
                }
            }
        }
        return saveJpeg(toBitmap(out, ow, oh), cacheDir, files[ref], true)
    }

    // ---------- HDR: exposure fusion of 3 frames (-2EV, 0, +2EV) ----------
    fun hdr(files: List<File>, cacheDir: File): File {
        val n = files.size
        val fr = files.map { loadPx(it) }
        val w = fr[0].w
        val h = fr[0].h
        val ref = n / 2
        val l8 = fr.map { lumaPx(it.px, w, h, 8) }
        val r8 = norm(l8[ref])
        val r2 = norm(lumaPx(fr[ref].px, w, h, 2))
        val dx = IntArray(n)
        val dy = IntArray(n)
        for (k in 0 until n) {
            if (k == ref) continue
            val s = alignShift(r8, r2, fr[k])
            dx[k] = s[0]
            dy[k] = s[1]
        }
        val ow = w - 2 * CROP
        val oh = h - 2 * CROP
        val lw = l8[0].w
        val lh = l8[0].h
        // well-exposedness weights at low resolution (smooth => no halos)
        val wm = Array(n) { k ->
            FloatArray(lw * lh) { i ->
                val v = l8[k].d[i] / 255f - 0.5f
                exp(-(v * v) / 0.08f) + 0.001f
            }
        }
        val xi0 = Array(n) { IntArray(ow) }
        val xi1 = Array(n) { IntArray(ow) }
        val xf = Array(n) { FloatArray(ow) }
        val sxs = Array(n) { IntArray(ow) }
        for (k in 0 until n) {
            for (x in 0 until ow) {
                val sx = (x + CROP + dx[k]).coerceIn(0, w - 1)
                sxs[k][x] = sx
                val u = ((sx + 0.5f) / 8f - 0.5f).coerceIn(0f, (lw - 1).toFloat())
                val i0 = floor(u).toInt()
                xi0[k][x] = i0
                xi1[k][x] = min(i0 + 1, lw - 1)
                xf[k][x] = u - i0
            }
        }
        val out = IntArray(ow * oh)
        Par.rows(oh) { y0, y1 ->
            val rowW = Array(n) { FloatArray(lw) }
            val sys = IntArray(n)
            for (y in y0 until y1) {
                for (k in 0 until n) {
                    val sy = (y + CROP + dy[k]).coerceIn(0, h - 1)
                    sys[k] = sy
                    val v = ((sy + 0.5f) / 8f - 0.5f).coerceIn(0f, (lh - 1).toFloat())
                    val j0 = floor(v).toInt()
                    val j1 = min(j0 + 1, lh - 1)
                    val fy = v - j0
                    val a = wm[k]
                    for (i in 0 until lw) {
                        rowW[k][i] = a[j0 * lw + i] * (1f - fy) + a[j1 * lw + i] * fy
                    }
                }
                for (x in 0 until ow) {
                    var sr = 0f
                    var sg = 0f
                    var sb = 0f
                    var sw = 0f
                    for (k in 0 until n) {
                        val f = xf[k][x]
                        val wk = rowW[k][xi0[k][x]] * (1f - f) + rowW[k][xi1[k][x]] * f
                        val p = fr[k].px[sys[k] * w + sxs[k][x]]
                        sr += wk * ((p shr 16) and 255)
                        sg += wk * ((p shr 8) and 255)
                        sb += wk * (p and 255)
                        sw += wk
                    }
                    val r = (sr / sw + 0.5f).toInt().coerceIn(0, 255)
                    val g = (sg / sw + 0.5f).toInt().coerceIn(0, 255)
                    val b = (sb / sw + 0.5f).toInt().coerceIn(0, 255)
                    out[y * ow + x] = (0xFF shl 24) or (r shl 16) or (g shl 8) or b
                }
            }
        }
        return saveJpeg(toBitmap(out, ow, oh), cacheDir, files[ref], true)
    }

    // ---------- Night: align + average N frames, then lift shadows ----------
    fun night(files: List<File>, cacheDir: File): File {
        val n = files.size
        val ref = loadPx(files[0])
        val w = ref.w
        val h = ref.h
        val ow = w - 2 * CROP
        val oh = h - 2 * CROP
        val sr = ShortArray(ow * oh)
        val sg = ShortArray(ow * oh)
        val sb = ShortArray(ow * oh)
        val r8 = norm(lumaPx(ref.px, w, h, 8))
        val r2 = norm(lumaPx(ref.px, w, h, 2))
        for (k in 0 until n) {
            val fr = if (k == 0) ref else loadPx(files[k])
            val s = if (k == 0) intArrayOf(0, 0) else alignShift(r8, r2, fr)
            val dx = s[0]
            val dy = s[1]
            Par.rows(oh) { y0, y1 ->
                for (y in y0 until y1) {
                    val ro = (y + CROP + dy).coerceIn(0, h - 1) * w
                    val oo = y * ow
                    for (x in 0 until ow) {
                        val p = fr.px[ro + (x + CROP + dx).coerceIn(0, w - 1)]
                        sr[oo + x] = (sr[oo + x] + ((p shr 16) and 255)).toShort()
                        sg[oo + x] = (sg[oo + x] + ((p shr 8) and 255)).toShort()
                        sb[oo + x] = (sb[oo + x] + (p and 255)).toShort()
                    }
                }
            }
        }
        var acc = 0L
        var cnt = 0
        var i = 0
        while (i < ow * oh) {
            acc += (77 * sr[i] + 150 * sg[i] + 29 * sb[i]) shr 8
            cnt++
            i += 97
        }
        val meanL = (acc.toFloat() / cnt / n / 255f).coerceAtLeast(0.01f)
        val gain = (0.38f / meanL).coerceIn(1f, 2.5f)
        val lut = IntArray(256) { v ->
            val x = min(1f, v / 255f * gain)
            (255f * (1f - exp(-1.8f * x)) / (1f - exp(-1.8f)) + 0.5f).toInt().coerceIn(0, 255)
        }
        val out = IntArray(ow * oh)
        Par.rows(oh) { y0, y1 ->
            for (y in y0 until y1) {
                val o = y * ow
                for (x in 0 until ow) {
                    val r = lut[((sr[o + x] + n / 2) / n).coerceIn(0, 255)]
                    val g = lut[((sg[o + x] + n / 2) / n).coerceIn(0, 255)]
                    val b = lut[((sb[o + x] + n / 2) / n).coerceIn(0, 255)]
                    out[o + x] = (0xFF shl 24) or (r shl 16) or (g shl 8) or b
                }
            }
        }
        return saveJpeg(toBitmap(out, ow, oh), cacheDir, files[0], true)
    }

    // ---------- Portrait: person mask (ML Kit) + blurred background ----------
    /** returns null if no person was found */
    fun portrait(file: File, cacheDir: File): File? {
        val src = decode(file)
        val deg = try {
            when (ExifInterface(file.absolutePath)
                .getAttributeInt(ExifInterface.TAG_ORIENTATION, ExifInterface.ORIENTATION_NORMAL)) {
                ExifInterface.ORIENTATION_ROTATE_90 -> 90
                ExifInterface.ORIENTATION_ROTATE_180 -> 180
                ExifInterface.ORIENTATION_ROTATE_270 -> 270
                else -> 0
            }
        } catch (e: Exception) { 0 }
        val bmp = if (deg != 0) {
            val m = Matrix().apply { postRotate(deg.toFloat()) }
            val r = Bitmap.createBitmap(src, 0, 0, src.width, src.height, m, true)
            src.recycle()
            r
        } else src
        val w = bmp.width
        val h = bmp.height

        val sc = 512f / max(w, h)
        val sw = max(1, (w * sc).toInt())
        val sh = max(1, (h * sc).toInt())
        val small = Bitmap.createScaledBitmap(bmp, sw, sh, true)
        val seg = Segmentation.getClient(
            SelfieSegmenterOptions.Builder()
                .setDetectorMode(SelfieSegmenterOptions.SINGLE_IMAGE_MODE)
                .build()
        )
        val mask = try {
            Tasks.await(seg.process(InputImage.fromBitmap(small, 0)))
        } finally {
            seg.close()
        }
        val mw = mask.width
        val mh = mask.height
        val raw = FloatArray(mw * mh)
        val bb = mask.buffer
        bb.rewind()
        for (i in raw.indices) raw[i] = bb.float
        small.recycle()
        var fg = 0
        for (v in raw) if (v > 0.5f) fg++
        if (fg < raw.size * 0.02f) {
            bmp.recycle()
            return null
        }
        val mm = blurF(blurF(raw, mw, mh, 3), mw, mh, 3)

        val bw = max(2, w / 4)
        val bh = max(2, h / 4)
        val tiny = Bitmap.createScaledBitmap(bmp, bw, bh, true)
        var px = IntArray(bw * bh)
        tiny.getPixels(px, 0, bw, 0, 0, bw, bh)
        tiny.recycle()
        repeat(3) { px = boxBlur(px, bw, bh, 7) }
        val tb = Bitmap.createBitmap(bw, bh, Bitmap.Config.ARGB_8888)
        tb.setPixels(px, 0, bw, 0, 0, bw, bh)
        val out = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)
        Canvas(out).drawBitmap(tb, null, Rect(0, 0, w, h), Paint(Paint.FILTER_BITMAP_FLAG))
        tb.recycle()

        val mx0 = IntArray(w)
        val mx1 = IntArray(w)
        val mxf = FloatArray(w)
        for (x in 0 until w) {
            val u = ((x + 0.5f) * mw / w - 0.5f).coerceIn(0f, (mw - 1).toFloat())
            val i0 = floor(u).toInt()
            mx0[x] = i0
            mx1[x] = min(i0 + 1, mw - 1)
            mxf[x] = u - i0
        }
        val rowO = IntArray(w)
        val rowB = IntArray(w)
        for (y in 0 until h) {
            bmp.getPixels(rowO, 0, w, 0, y, w, 1)
            out.getPixels(rowB, 0, w, 0, y, w, 1)
            val v = ((y + 0.5f) * mh / h - 0.5f).coerceIn(0f, (mh - 1).toFloat())
            val j0 = floor(v).toInt()
            val j1 = min(j0 + 1, mh - 1)
            val fy = v - j0
            for (x in 0 until w) {
                val a = mm[j0 * mw + mx0[x]] * (1f - mxf[x]) + mm[j0 * mw + mx1[x]] * mxf[x]
                val b = mm[j1 * mw + mx0[x]] * (1f - mxf[x]) + mm[j1 * mw + mx1[x]] * mxf[x]
                var t = ((a * (1f - fy) + b * fy) - 0.3f) / 0.4f
                t = t.coerceIn(0f, 1f)
                t = t * t * (3f - 2f * t)
                val po = rowO[x]
                val pb = rowB[x]
                val r = (((po shr 16) and 255) * t + ((pb shr 16) and 255) * (1f - t) + 0.5f).toInt()
                val g = (((po shr 8) and 255) * t + ((pb shr 8) and 255) * (1f - t) + 0.5f).toInt()
                val bl = ((po and 255) * t + (pb and 255) * (1f - t) + 0.5f).toInt()
                rowB[x] = (0xFF shl 24) or (r.coerceIn(0, 255) shl 16) or
                    (g.coerceIn(0, 255) shl 8) or bl.coerceIn(0, 255)
            }
            out.setPixels(rowB, 0, w, 0, y, w, 1)
        }
        bmp.recycle()
        return saveJpeg(out, cacheDir, file, false)
    }

    internal fun blurF(a: FloatArray, w: Int, h: Int, r: Int): FloatArray {
        val t = FloatArray(a.size)
        val o = FloatArray(a.size)
        val d = (2 * r + 1).toFloat()
        for (y in 0 until h) {
            for (x in 0 until w) {
                var s = 0f
                for (i in -r..r) s += a[y * w + (x + i).coerceIn(0, w - 1)]
                t[y * w + x] = s / d
            }
        }
        for (y in 0 until h) {
            for (x in 0 until w) {
                var s = 0f
                for (i in -r..r) s += t[(y + i).coerceIn(0, h - 1) * w + x]
                o[y * w + x] = s / d
            }
        }
        return o
    }

    private fun boxBlur(px: IntArray, w: Int, h: Int, r: Int): IntArray {
        val d = 2 * r + 1
        val tmp = IntArray(w * h)
        val out = IntArray(w * h)
        for (y in 0 until h) {
            val ro = y * w
            var sr = 0
            var sg = 0
            var sb = 0
            for (i in -r..r) {
                val p = px[ro + i.coerceIn(0, w - 1)]
                sr += (p shr 16) and 255
                sg += (p shr 8) and 255
                sb += p and 255
            }
            for (x in 0 until w) {
                tmp[ro + x] = (0xFF shl 24) or ((sr / d) shl 16) or ((sg / d) shl 8) or (sb / d)
                val a = px[ro + min(x + r + 1, w - 1)]
                val b = px[ro + max(x - r, 0)]
                sr += ((a shr 16) and 255) - ((b shr 16) and 255)
                sg += ((a shr 8) and 255) - ((b shr 8) and 255)
                sb += (a and 255) - (b and 255)
            }
        }
        for (x in 0 until w) {
            var sr = 0
            var sg = 0
            var sb = 0
            for (i in -r..r) {
                val p = tmp[i.coerceIn(0, h - 1) * w + x]
                sr += (p shr 16) and 255
                sg += (p shr 8) and 255
                sb += p and 255
            }
            for (y in 0 until h) {
                out[y * w + x] = (0xFF shl 24) or ((sr / d) shl 16) or ((sg / d) shl 8) or (sb / d)
                val a = tmp[min(y + r + 1, h - 1) * w + x]
                val b = tmp[max(y - r, 0) * w + x]
                sr += ((a shr 16) and 255) - ((b shr 16) and 255)
                sg += ((a shr 8) and 255) - ((b shr 8) and 255)
                sb += (a and 255) - (b and 255)
            }
        }
        return out
    }
}
