package com.proshot.camera

import java.util.concurrent.Executors
import java.util.concurrent.Future
import kotlin.math.min

/** Tiny helper: runs a row-range job on all CPU cores. */
object Par {
    private val cores = Runtime.getRuntime().availableProcessors().coerceIn(2, 8)
    private val pool = Executors.newFixedThreadPool(cores) { r ->
        Thread(r).apply { isDaemon = true }
    }

    fun rows(h: Int, body: (Int, Int) -> Unit) {
        val bands = cores * 3
        val step = (h + bands - 1) / bands
        val fs = ArrayList<Future<*>>()
        var y = 0
        while (y < h) {
            val y0 = y
            val y1 = min(h, y + step)
            fs.add(pool.submit(Runnable { body(y0, y1) }))
            y = y1
        }
        for (f in fs) f.get()
    }
}
